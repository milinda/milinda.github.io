"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.defineRoutes = defineRoutes;

var _configSchema = require("@kbn/config-schema");

var _common = require("../../common");

/*
 *   Copyright 2020 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 *   Licensed under the Apache License, Version 2.0 (the "License").
 *   You may not use this file except in compliance with the License.
 *   A copy of the License is located at
 *
 *       http://www.apache.org/licenses/LICENSE-2.0
 *
 *   or in the "license" file accompanying this file. This file is distributed
 *   on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 *   express or implied. See the License for the specific language governing
 *   permissions and limitations under the License.
 */
// TODO: consider to extract entity CRUD operations and put it into a client class
function defineRoutes(router) {
  const internalUserSchema = _configSchema.schema.object({
    description: _configSchema.schema.maybe(_configSchema.schema.string()),
    password: _configSchema.schema.string(),
    backend_roles: _configSchema.schema.arrayOf(_configSchema.schema.string(), {
      defaultValue: []
    }),
    attributes: _configSchema.schema.any({
      defaultValue: {}
    })
  });

  const actionGroupSchema = _configSchema.schema.object({
    description: _configSchema.schema.maybe(_configSchema.schema.string()),
    allowed_actions: _configSchema.schema.arrayOf(_configSchema.schema.string()) // type field is not supported in legacy implementation, comment it out for now.
    // type: schema.oneOf([
    //   schema.literal('cluster'),
    //   schema.literal('index'),
    //   schema.literal('kibana'),
    // ]),

  });

  const roleMappingSchema = _configSchema.schema.object({
    description: _configSchema.schema.maybe(_configSchema.schema.string()),
    backend_roles: _configSchema.schema.arrayOf(_configSchema.schema.string(), {
      defaultValue: []
    }),
    hosts: _configSchema.schema.arrayOf(_configSchema.schema.string(), {
      defaultValue: []
    }),
    users: _configSchema.schema.arrayOf(_configSchema.schema.string(), {
      defaultValue: []
    })
  });

  const roleSchema = _configSchema.schema.object({
    description: _configSchema.schema.maybe(_configSchema.schema.string()),
    cluster_permissions: _configSchema.schema.arrayOf(_configSchema.schema.string(), {
      defaultValue: []
    }),
    tenant_permissions: _configSchema.schema.arrayOf(_configSchema.schema.any(), {
      defaultValue: []
    }),
    index_permissions: _configSchema.schema.arrayOf(_configSchema.schema.any(), {
      defaultValue: []
    })
  });

  const tenantSchema = _configSchema.schema.object({
    description: _configSchema.schema.string()
  });

  const accountSchema = _configSchema.schema.object({
    password: _configSchema.schema.string(),
    current_password: _configSchema.schema.string()
  });

  const schemaMap = {
    internalusers: internalUserSchema,
    actiongroups: actionGroupSchema,
    rolesmapping: roleMappingSchema,
    roles: roleSchema,
    tenants: tenantSchema,
    account: accountSchema
  };

  function validateRequestBody(resourceName, requestBody) {
    const inputSchema = schemaMap[resourceName];

    if (!inputSchema) {
      throw new Error(`Unknown resource ${resourceName}`);
    }

    inputSchema.validate(requestBody); // throws error if validation fail
  }

  function validateEntityId(resourceName) {
    if (!(0, _common.isValidResourceName)(resourceName)) {
      return 'Invalid entity name or id.';
    }
  }
  /**
   * Lists resources by resource name.
   *
   * The response format is:
   * {
   *   "total": <total_entity_count>,
   *   "data": {
   *     "entity_id_1": { <entity_structure> },
   *     "entity_id_2": { <entity_structure> },
   *     ...
   *   }
   * }
   *
   * e.g. when listing internal users, response may look like:
   * {
   *   "total": 2,
   *   "data": {
   *     "api_test_user2": {
   *       "hash": "",
   *       "reserved": false,
   *       "hidden": false,
   *       "backend_roles": [],
   *       "attributes": {},
   *       "description": "",
   *       "static": false
   *     },
   *     "api_test_user1": {
   *       "hash": "",
   *       "reserved": false,
   *       "hidden": false,
   *       "backend_roles": [],
   *       "attributes": {},
   *       "static": false
   *     }
   * }
   *
   * when listing action groups, response will look like:
   * {
   *   "total": 2,
   *   "data": {
   *     "read": {
   *       "reserved": true,
   *       "hidden": false,
   *       "allowed_actions": ["indices:data/read*", "indices:admin/mappings/fields/get*"],
   *       "type": "index",
   *       "description": "Allow all read operations",
   *       "static": false
   *     },
   *     "cluster_all": {
   *       "reserved": true,
   *       "hidden": false,
   *       "allowed_actions": ["cluster:*"],
   *       "type": "cluster",
   *       "description": "Allow everything on cluster level",
   *       "static": false
   *     }
   * }
   *
   * role:
   * {
   *   "total": 2,
   *   "data": {
   *     "kibana_user": {
   *       "reserved": true,
   *       "hidden": false,
   *       "description": "Provide the minimum permissions for a kibana user",
   *       "cluster_permissions": ["cluster_composite_ops"],
   *       "index_permissions": [{
   *         "index_patterns": [".kibana", ".kibana-6", ".kibana_*"],
   *         "fls": [],
   *         "masked_fields": [],
   *         "allowed_actions": ["read", "delete", "manage", "index"]
   *       }, {
   *         "index_patterns": [".tasks", ".management-beats"],
   *         "fls": [],
   *         "masked_fields": [],
   *         "allowed_actions": ["indices_all"]
   *       }],
   *       "tenant_permissions": [],
   *       "static": false
   *     },
   *     "all_access": {
   *       "reserved": true,
   *       "hidden": false,
   *       "description": "Allow full access to all indices and all cluster APIs",
   *       "cluster_permissions": ["*"],
   *       "index_permissions": [{
   *         "index_patterns": ["*"],
   *         "fls": [],
   *         "masked_fields": [],
   *         "allowed_actions": ["*"]
   *       }],
   *       "tenant_permissions": [{
   *         "tenant_patterns": ["*"],
   *         "allowed_actions": ["kibana_all_write"]
   *       }],
   *       "static": false
   *     }
   *   }
   * }
   *
   * rolesmapping:
   * {
   *   "total": 2,
   *   "data": {
   *     "security_manager": {
   *       "reserved": false,
   *       "hidden": false,
   *       "backend_roles": [],
   *       "hosts": [],
   *       "users": ["zengyan", "admin"],
   *       "and_backend_roles": []
   *     },
   *     "all_access": {
   *       "reserved": false,
   *       "hidden": false,
   *       "backend_roles": [],
   *       "hosts": [],
   *       "users": ["zengyan", "admin", "indextest"],
   *       "and_backend_roles": []
   *     }
   *   }
   * }
   *
   * tenants:
   * {
   *   "total": 2,
   *   "data": {
   *     "global_tenant": {
   *       "reserved": true,
   *       "hidden": false,
   *       "description": "Global tenant",
   *       "static": false
   *     },
   *     "test tenant": {
   *       "reserved": false,
   *       "hidden": false,
   *       "description": "tenant description",
   *       "static": false
   *     }
   *   }
   * }
   */


  router.get({
    path: `${_common.API_PREFIX}/${_common.CONFIGURATION_API_PREFIX}/{resourceName}`,
    validate: {
      params: _configSchema.schema.object({
        resourceName: _configSchema.schema.string()
      })
    }
  }, async (context, request, response) => {
    const client = context.security_plugin.esClient.asScoped(request);
    let esResp;

    try {
      esResp = await client.callAsCurrentUser('opendistro_security.listResource', {
        resourceName: request.params.resourceName
      });
      return response.ok({
        body: {
          total: Object.keys(esResp).length,
          data: esResp
        }
      });
    } catch (error) {
      console.log(JSON.stringify(error));
      return errorResponse(response, error);
    }
  });
  /**
   * Gets entity by id.
   *
   * the response format differs from different resource types. e.g.
   *
   * for internal user, response will look like:
   * {
   *   "hash": "",
   *   "reserved": false,
   *   "hidden": false,
   *   "backend_roles": [],
   *   "attributes": {},
   *   "static": false
   * }
   *
   * for role, response will look like:
   * {
   *   "reserved": true,
   *   "hidden": false,
   *   "description": "Allow full access to all indices and all cluster APIs",
   *   "cluster_permissions": ["*"],
   *   "index_permissions": [{
   *     "index_patterns": ["*"],
   *     "fls": [],
   *     "masked_fields": [],
   *     "allowed_actions": ["*"]
   *   }],
   *   "tenant_permissions": [{
   *     "tenant_patterns": ["*"],
   *     "allowed_actions": ["kibana_all_write"]
   *   }],
   *   "static": false
   * }
   *
   * for roles mapping, response will look like:
   * {
   *   "reserved": true,
   *   "hidden": false,
   *   "description": "Allow full access to all indices and all cluster APIs",
   *   "cluster_permissions": ["*"],
   *   "index_permissions": [{
   *     "index_patterns": ["*"],
   *     "fls": [],
   *     "masked_fields": [],
   *     "allowed_actions": ["*"]
   *   }],
   *   "tenant_permissions": [{
   *     "tenant_patterns": ["*"],
   *     "allowed_actions": ["kibana_all_write"]
   *   }],
   *   "static": false
   * }
   *
   * for action groups, response will look like:
   * {
   *   "reserved": true,
   *   "hidden": false,
   *   "allowed_actions": ["indices:data/read*", "indices:admin/mappings/fields/get*"],
   *   "type": "index",
   *   "description": "Allow all read operations",
   *   "static": false
   * }
   *
   * for tenant, response will look like:
   * {
   *   "reserved": true,
   *   "hidden": false,
   *   "description": "Global tenant",
   *   "static": false
   * },
   */

  router.get({
    path: `${_common.API_PREFIX}/${_common.CONFIGURATION_API_PREFIX}/{resourceName}/{id}`,
    validate: {
      params: _configSchema.schema.object({
        resourceName: _configSchema.schema.string(),
        id: _configSchema.schema.string()
      })
    }
  }, async (context, request, response) => {
    const client = context.security_plugin.esClient.asScoped(request);
    let esResp;

    try {
      esResp = await client.callAsCurrentUser('opendistro_security.getResource', {
        resourceName: request.params.resourceName,
        id: request.params.id
      });
      return response.ok({
        body: esResp[request.params.id]
      });
    } catch (error) {
      return errorResponse(response, error);
    }
  });
  /**
   * Deletes an entity by id.
   */

  router.delete({
    path: `${_common.API_PREFIX}/${_common.CONFIGURATION_API_PREFIX}/{resourceName}/{id}`,
    validate: {
      params: _configSchema.schema.object({
        resourceName: _configSchema.schema.string(),
        id: _configSchema.schema.string({
          minLength: 1
        })
      })
    }
  }, async (context, request, response) => {
    const client = context.security_plugin.esClient.asScoped(request);
    let esResp;

    try {
      esResp = await client.callAsCurrentUser('opendistro_security.deleteResource', {
        resourceName: request.params.resourceName,
        id: request.params.id
      });
      return response.ok({
        body: {
          message: esResp.message
        }
      });
    } catch (error) {
      return errorResponse(response, error);
    }
  });
  /**
   * Update object with out Id. Resource identification is expected to computed from headers. Eg: auth headers
   *
   * Request sample:
   * /configuration/account
   * {
   *   "password": "new-password",
   *   "current_password": "old-password"
   * }
   */

  router.post({
    path: `${_common.API_PREFIX}/${_common.CONFIGURATION_API_PREFIX}/{resourceName}`,
    validate: {
      params: _configSchema.schema.object({
        resourceName: _configSchema.schema.string()
      }),
      body: _configSchema.schema.any()
    }
  }, async (context, request, response) => {
    try {
      validateRequestBody(request.params.resourceName, request.body);
    } catch (error) {
      return response.badRequest({
        body: error
      });
    }

    const client = context.security_plugin.esClient.asScoped(request);
    let esResp;

    try {
      esResp = await client.callAsCurrentUser('opendistro_security.saveResourceWithoutId', {
        resourceName: request.params.resourceName,
        body: request.body
      });
      return response.ok({
        body: {
          message: esResp.message
        }
      });
    } catch (error) {
      return errorResponse(response, error);
    }
  });
  /**
   * Update entity by Id.
   */

  router.post({
    path: `${_common.API_PREFIX}/${_common.CONFIGURATION_API_PREFIX}/{resourceName}/{id}`,
    validate: {
      params: _configSchema.schema.object({
        resourceName: _configSchema.schema.string(),
        id: _configSchema.schema.string({
          validate: validateEntityId
        })
      }),
      body: _configSchema.schema.any()
    }
  }, async (context, request, response) => {
    try {
      validateRequestBody(request.params.resourceName, request.body);
    } catch (error) {
      return response.badRequest({
        body: error
      });
    }

    const client = context.security_plugin.esClient.asScoped(request);
    let esResp;

    try {
      esResp = await client.callAsCurrentUser('opendistro_security.saveResource', {
        resourceName: request.params.resourceName,
        id: request.params.id,
        body: request.body
      });
      return response.ok({
        body: {
          message: esResp.message
        }
      });
    } catch (error) {
      return errorResponse(response, error);
    }
  });
  /**
   * Gets authentication info of the user.
   *
   * The response looks like:
   * {
   *   "user": "User [name=admin, roles=[], requestedTenant=__user__]",
   *   "user_name": "admin",
   *   "user_requested_tenant": "__user__",
   *   "remote_address": "127.0.0.1:35044",
   *   "backend_roles": [],
   *   "custom_attribute_names": [],
   *   "roles": ["all_access", "security_manager"],
   *   "tenants": {
   *     "another_tenant": true,
   *     "admin": true,
   *     "global_tenant": true,
   *     "aaaaa": true,
   *     "test tenant": true
   *   },
   *   "principal": null,
   *   "peer_certificates": "0",
   *   "sso_logout_url": null
   * }
   */

  router.get({
    path: `${_common.API_PREFIX}/auth/authinfo`,
    validate: false
  }, async (context, request, response) => {
    const client = context.security_plugin.esClient.asScoped(request);
    let esResp;

    try {
      esResp = await client.callAsCurrentUser('opendistro_security.authinfo');
      return response.ok({
        body: esResp
      });
    } catch (error) {
      return errorResponse(response, error);
    }
  });
  /**
   * Gets audit log configuration。
   *
   * Sample payload:
   * {
   *   "enabled":true,
   *   "audit":{
   *     "enable_rest":false,
   *     "disabled_rest_categories":[
   *       "FAILED_LOGIN",
   *       "AUTHENTICATED"
   *     ],
   *     "enable_transport":true,
   *     "disabled_transport_categories":[
   *       "GRANTED_PRIVILEGES"
   *     ],
   *     "resolve_bulk_requests":true,
   *     "log_request_body":false,
   *     "resolve_indices":true,
   *     "exclude_sensitive_headers":true,
   *     "ignore_users":[
   *       "admin",
   *     ],
   *     "ignore_requests":[
   *       "SearchRequest",
   *       "indices:data/read/*"
   *     ]
   *   },
   *   "compliance":{
   *     "enabled":true,
   *     "internal_config":false,
   *     "external_config":false,
   *     "read_metadata_only":false,
   *     "read_watched_fields":{
   *       "indexName1":[
   *         "field1",
   *         "fields-*"
   *       ]
   *     },
   *     "read_ignore_users":[
   *       "kibanaserver",
   *       "operator/*"
   *     ],
   *     "write_metadata_only":false,
   *     "write_log_diffs":false,
   *     "write_watched_indices":[
   *       "indexName2",
   *       "indexPatterns-*"
   *     ],
   *     "write_ignore_users":[
   *       "admin"
   *     ]
   *   }
   * }
   */

  router.get({
    path: `${_common.API_PREFIX}/configuration/audit`,
    validate: false
  }, async (context, request, response) => {
    const client = context.security_plugin.esClient.asScoped(request);
    let esResp;

    try {
      esResp = await client.callAsCurrentUser('opendistro_security.getAudit');
      return response.ok({
        body: esResp
      });
    } catch (error) {
      return response.custom({
        statusCode: error.statusCode,
        body: parseEsErrorResponse(error)
      });
    }
  });
  /**
   * Update audit log configuration。
   *
   * Sample payload:
   * {
   *   "enabled":true,
   *   "audit":{
   *     "enable_rest":false,
   *     "disabled_rest_categories":[
   *       "FAILED_LOGIN",
   *       "AUTHENTICATED"
   *     ],
   *     "enable_transport":true,
   *     "disabled_transport_categories":[
   *       "GRANTED_PRIVILEGES"
   *     ],
   *     "resolve_bulk_requests":true,
   *     "log_request_body":false,
   *     "resolve_indices":true,
   *     "exclude_sensitive_headers":true,
   *     "ignore_users":[
   *       "admin",
   *     ],
   *     "ignore_requests":[
   *       "SearchRequest",
   *       "indices:data/read/*"
   *     ]
   *   },
   *   "compliance":{
   *     "enabled":true,
   *     "internal_config":false,
   *     "external_config":false,
   *     "read_metadata_only":false,
   *     "read_watched_fields":{
   *       "indexName1":[
   *         "field1",
   *         "fields-*"
   *       ]
   *     },
   *     "read_ignore_users":[
   *       "kibanaserver",
   *       "operator/*"
   *     ],
   *     "write_metadata_only":false,
   *     "write_log_diffs":false,
   *     "write_watched_indices":[
   *       "indexName2",
   *       "indexPatterns-*"
   *     ],
   *     "write_ignore_users":[
   *       "admin"
   *     ]
   *   }
   * }
   */

  router.post({
    path: `${_common.API_PREFIX}/configuration/audit/config`,
    validate: {
      body: _configSchema.schema.any()
    }
  }, async (context, request, response) => {
    const client = context.security_plugin.esClient.asScoped(request);
    let esResp;

    try {
      esResp = await client.callAsCurrentUser('opendistro_security.saveAudit', {
        body: request.body
      });
      return response.ok({
        body: {
          message: esResp.message
        }
      });
    } catch (error) {
      return errorResponse(response, error);
    }
  });
  /**
   * Deletes cache.
   *
   * Sample response: {"message":"Cache flushed successfully."}
   */

  router.delete({
    path: `${_common.API_PREFIX}/configuration/cache`,
    validate: false
  }, async (context, request, response) => {
    const client = context.security_plugin.esClient.asScoped(request);
    let esResponse;

    try {
      esResponse = await client.callAsCurrentUser('opendistro_security.clearCache');
      return response.ok({
        body: {
          message: esResponse.message
        }
      });
    } catch (error) {
      return errorResponse(response, error);
    }
  });
  /**
   * Gets permission info of current user.
   *
   * Sample response:
   * {
   *   "user": "User [name=admin, roles=[], requestedTenant=__user__]",
   *   "user_name": "admin",
   *   "has_api_access": true,
   *   "disabled_endpoints": {}
   * }
   */

  router.get({
    path: `${_common.API_PREFIX}/restapiinfo`,
    validate: false
  }, async (context, request, response) => {
    const client = context.security_plugin.esClient.asScoped(request);

    try {
      const esResponse = await client.callAsCurrentUser('opendistro_security.restapiinfo');
      return response.ok({
        body: esResponse
      });
    } catch (error) {
      return response.badRequest({
        body: error
      });
    }
  });
  /**
   * Validates DLS (document level security) query.
   *
   * Request payload is an ES query.
   */

  router.post({
    path: `${_common.API_PREFIX}/${_common.CONFIGURATION_API_PREFIX}/validatedls/{indexName}`,
    validate: {
      params: _configSchema.schema.object({
        // in legacy plugin implmentation, indexName is not used when calling ES API.
        indexName: _configSchema.schema.maybe(_configSchema.schema.string())
      }),
      body: _configSchema.schema.any()
    }
  }, async (context, request, response) => {
    const client = context.security_plugin.esClient.asScoped(request);

    try {
      const esResponse = await client.callAsCurrentUser('opendistro_security.validateDls', {
        body: request.body
      });
      return response.ok({
        body: esResponse
      });
    } catch (error) {
      return errorResponse(response, error);
    }
  });
  /**
   * Gets index mapping.
   *
   * Calling ES _mapping API under the hood. see
   * https://www.elastic.co/guide/en/elasticsearch/reference/current/indices-get-mapping.html
   */

  router.post({
    path: `${_common.API_PREFIX}/${_common.CONFIGURATION_API_PREFIX}/index_mappings`,
    validate: {
      body: _configSchema.schema.object({
        index: _configSchema.schema.arrayOf(_configSchema.schema.string())
      })
    }
  }, async (context, request, response) => {
    const client = context.security_plugin.esClient.asScoped(request);

    try {
      const esResponse = await client.callAsCurrentUser('opendistro_security.getIndexMappings', {
        index: request.body.index.join(','),
        ignore_unavailable: true,
        allow_no_indices: true
      });
      return response.ok({
        body: esResponse
      });
    } catch (error) {
      return errorResponse(response, error);
    }
  });
  /**
   * Gets all indices, and field mappings.
   *
   * Calls ES API '/_all/_mapping/field/*' under the hood. see
   * https://www.elastic.co/guide/en/elasticsearch/reference/current/indices-get-mapping.html
   */

  router.get({
    path: `${_common.API_PREFIX}/${_common.CONFIGURATION_API_PREFIX}/indices`,
    validate: false
  }, async (context, request, response) => {
    const client = context.security_plugin.esClient.asScoped(request);

    try {
      const esResponse = await client.callAsCurrentUser('opendistro_security.indices');
      return response.ok({
        body: esResponse
      });
    } catch (error) {
      return errorResponse(response, error);
    }
  });
}

function parseEsErrorResponse(error) {
  if (error.response) {
    try {
      const esErrorResponse = JSON.parse(error.response);
      return esErrorResponse.reason || error.response;
    } catch (parsingError) {
      return error.response;
    }
  }

  return error.message;
}

function errorResponse(response, error) {
  return response.custom({
    statusCode: error.statusCode,
    body: parseEsErrorResponse(error)
  });
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImluZGV4LnRzIl0sIm5hbWVzIjpbImRlZmluZVJvdXRlcyIsInJvdXRlciIsImludGVybmFsVXNlclNjaGVtYSIsInNjaGVtYSIsIm9iamVjdCIsImRlc2NyaXB0aW9uIiwibWF5YmUiLCJzdHJpbmciLCJwYXNzd29yZCIsImJhY2tlbmRfcm9sZXMiLCJhcnJheU9mIiwiZGVmYXVsdFZhbHVlIiwiYXR0cmlidXRlcyIsImFueSIsImFjdGlvbkdyb3VwU2NoZW1hIiwiYWxsb3dlZF9hY3Rpb25zIiwicm9sZU1hcHBpbmdTY2hlbWEiLCJob3N0cyIsInVzZXJzIiwicm9sZVNjaGVtYSIsImNsdXN0ZXJfcGVybWlzc2lvbnMiLCJ0ZW5hbnRfcGVybWlzc2lvbnMiLCJpbmRleF9wZXJtaXNzaW9ucyIsInRlbmFudFNjaGVtYSIsImFjY291bnRTY2hlbWEiLCJjdXJyZW50X3Bhc3N3b3JkIiwic2NoZW1hTWFwIiwiaW50ZXJuYWx1c2VycyIsImFjdGlvbmdyb3VwcyIsInJvbGVzbWFwcGluZyIsInJvbGVzIiwidGVuYW50cyIsImFjY291bnQiLCJ2YWxpZGF0ZVJlcXVlc3RCb2R5IiwicmVzb3VyY2VOYW1lIiwicmVxdWVzdEJvZHkiLCJpbnB1dFNjaGVtYSIsIkVycm9yIiwidmFsaWRhdGUiLCJ2YWxpZGF0ZUVudGl0eUlkIiwiZ2V0IiwicGF0aCIsIkFQSV9QUkVGSVgiLCJDT05GSUdVUkFUSU9OX0FQSV9QUkVGSVgiLCJwYXJhbXMiLCJjb250ZXh0IiwicmVxdWVzdCIsInJlc3BvbnNlIiwiY2xpZW50Iiwic2VjdXJpdHlfcGx1Z2luIiwiZXNDbGllbnQiLCJhc1Njb3BlZCIsImVzUmVzcCIsImNhbGxBc0N1cnJlbnRVc2VyIiwib2siLCJib2R5IiwidG90YWwiLCJPYmplY3QiLCJrZXlzIiwibGVuZ3RoIiwiZGF0YSIsImVycm9yIiwiY29uc29sZSIsImxvZyIsIkpTT04iLCJzdHJpbmdpZnkiLCJlcnJvclJlc3BvbnNlIiwiaWQiLCJkZWxldGUiLCJtaW5MZW5ndGgiLCJtZXNzYWdlIiwicG9zdCIsImJhZFJlcXVlc3QiLCJjdXN0b20iLCJzdGF0dXNDb2RlIiwicGFyc2VFc0Vycm9yUmVzcG9uc2UiLCJlc1Jlc3BvbnNlIiwiaW5kZXhOYW1lIiwiaW5kZXgiLCJqb2luIiwiaWdub3JlX3VuYXZhaWxhYmxlIiwiYWxsb3dfbm9faW5kaWNlcyIsImVzRXJyb3JSZXNwb25zZSIsInBhcnNlIiwicmVhc29uIiwicGFyc2luZ0Vycm9yIl0sIm1hcHBpbmdzIjoiOzs7Ozs7O0FBZUE7O0FBRUE7O0FBakJBOzs7Ozs7Ozs7Ozs7OztBQW1CQTtBQUNPLFNBQVNBLFlBQVQsQ0FBc0JDLE1BQXRCLEVBQXVDO0FBQzVDLFFBQU1DLGtCQUFrQixHQUFHQyxxQkFBT0MsTUFBUCxDQUFjO0FBQ3ZDQyxJQUFBQSxXQUFXLEVBQUVGLHFCQUFPRyxLQUFQLENBQWFILHFCQUFPSSxNQUFQLEVBQWIsQ0FEMEI7QUFFdkNDLElBQUFBLFFBQVEsRUFBRUwscUJBQU9JLE1BQVAsRUFGNkI7QUFHdkNFLElBQUFBLGFBQWEsRUFBRU4scUJBQU9PLE9BQVAsQ0FBZVAscUJBQU9JLE1BQVAsRUFBZixFQUFnQztBQUFFSSxNQUFBQSxZQUFZLEVBQUU7QUFBaEIsS0FBaEMsQ0FId0I7QUFJdkNDLElBQUFBLFVBQVUsRUFBRVQscUJBQU9VLEdBQVAsQ0FBVztBQUFFRixNQUFBQSxZQUFZLEVBQUU7QUFBaEIsS0FBWDtBQUoyQixHQUFkLENBQTNCOztBQU9BLFFBQU1HLGlCQUFpQixHQUFHWCxxQkFBT0MsTUFBUCxDQUFjO0FBQ3RDQyxJQUFBQSxXQUFXLEVBQUVGLHFCQUFPRyxLQUFQLENBQWFILHFCQUFPSSxNQUFQLEVBQWIsQ0FEeUI7QUFFdENRLElBQUFBLGVBQWUsRUFBRVoscUJBQU9PLE9BQVAsQ0FBZVAscUJBQU9JLE1BQVAsRUFBZixDQUZxQixDQUd0QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBUnNDLEdBQWQsQ0FBMUI7O0FBV0EsUUFBTVMsaUJBQWlCLEdBQUdiLHFCQUFPQyxNQUFQLENBQWM7QUFDdENDLElBQUFBLFdBQVcsRUFBRUYscUJBQU9HLEtBQVAsQ0FBYUgscUJBQU9JLE1BQVAsRUFBYixDQUR5QjtBQUV0Q0UsSUFBQUEsYUFBYSxFQUFFTixxQkFBT08sT0FBUCxDQUFlUCxxQkFBT0ksTUFBUCxFQUFmLEVBQWdDO0FBQUVJLE1BQUFBLFlBQVksRUFBRTtBQUFoQixLQUFoQyxDQUZ1QjtBQUd0Q00sSUFBQUEsS0FBSyxFQUFFZCxxQkFBT08sT0FBUCxDQUFlUCxxQkFBT0ksTUFBUCxFQUFmLEVBQWdDO0FBQUVJLE1BQUFBLFlBQVksRUFBRTtBQUFoQixLQUFoQyxDQUgrQjtBQUl0Q08sSUFBQUEsS0FBSyxFQUFFZixxQkFBT08sT0FBUCxDQUFlUCxxQkFBT0ksTUFBUCxFQUFmLEVBQWdDO0FBQUVJLE1BQUFBLFlBQVksRUFBRTtBQUFoQixLQUFoQztBQUorQixHQUFkLENBQTFCOztBQU9BLFFBQU1RLFVBQVUsR0FBR2hCLHFCQUFPQyxNQUFQLENBQWM7QUFDL0JDLElBQUFBLFdBQVcsRUFBRUYscUJBQU9HLEtBQVAsQ0FBYUgscUJBQU9JLE1BQVAsRUFBYixDQURrQjtBQUUvQmEsSUFBQUEsbUJBQW1CLEVBQUVqQixxQkFBT08sT0FBUCxDQUFlUCxxQkFBT0ksTUFBUCxFQUFmLEVBQWdDO0FBQUVJLE1BQUFBLFlBQVksRUFBRTtBQUFoQixLQUFoQyxDQUZVO0FBRy9CVSxJQUFBQSxrQkFBa0IsRUFBRWxCLHFCQUFPTyxPQUFQLENBQWVQLHFCQUFPVSxHQUFQLEVBQWYsRUFBNkI7QUFBRUYsTUFBQUEsWUFBWSxFQUFFO0FBQWhCLEtBQTdCLENBSFc7QUFJL0JXLElBQUFBLGlCQUFpQixFQUFFbkIscUJBQU9PLE9BQVAsQ0FBZVAscUJBQU9VLEdBQVAsRUFBZixFQUE2QjtBQUFFRixNQUFBQSxZQUFZLEVBQUU7QUFBaEIsS0FBN0I7QUFKWSxHQUFkLENBQW5COztBQU9BLFFBQU1ZLFlBQVksR0FBR3BCLHFCQUFPQyxNQUFQLENBQWM7QUFDakNDLElBQUFBLFdBQVcsRUFBRUYscUJBQU9JLE1BQVA7QUFEb0IsR0FBZCxDQUFyQjs7QUFJQSxRQUFNaUIsYUFBYSxHQUFHckIscUJBQU9DLE1BQVAsQ0FBYztBQUNsQ0ksSUFBQUEsUUFBUSxFQUFFTCxxQkFBT0ksTUFBUCxFQUR3QjtBQUVsQ2tCLElBQUFBLGdCQUFnQixFQUFFdEIscUJBQU9JLE1BQVA7QUFGZ0IsR0FBZCxDQUF0Qjs7QUFLQSxRQUFNbUIsU0FBYyxHQUFHO0FBQ3JCQyxJQUFBQSxhQUFhLEVBQUV6QixrQkFETTtBQUVyQjBCLElBQUFBLFlBQVksRUFBRWQsaUJBRk87QUFHckJlLElBQUFBLFlBQVksRUFBRWIsaUJBSE87QUFJckJjLElBQUFBLEtBQUssRUFBRVgsVUFKYztBQUtyQlksSUFBQUEsT0FBTyxFQUFFUixZQUxZO0FBTXJCUyxJQUFBQSxPQUFPLEVBQUVSO0FBTlksR0FBdkI7O0FBU0EsV0FBU1MsbUJBQVQsQ0FBNkJDLFlBQTdCLEVBQW1EQyxXQUFuRCxFQUEwRTtBQUN4RSxVQUFNQyxXQUFXLEdBQUdWLFNBQVMsQ0FBQ1EsWUFBRCxDQUE3Qjs7QUFDQSxRQUFJLENBQUNFLFdBQUwsRUFBa0I7QUFDaEIsWUFBTSxJQUFJQyxLQUFKLENBQVcsb0JBQW1CSCxZQUFhLEVBQTNDLENBQU47QUFDRDs7QUFDREUsSUFBQUEsV0FBVyxDQUFDRSxRQUFaLENBQXFCSCxXQUFyQixFQUx3RSxDQUtyQztBQUNwQzs7QUFFRCxXQUFTSSxnQkFBVCxDQUEwQkwsWUFBMUIsRUFBZ0Q7QUFDOUMsUUFBSSxDQUFDLGlDQUFvQkEsWUFBcEIsQ0FBTCxFQUF3QztBQUN0QyxhQUFPLDRCQUFQO0FBQ0Q7QUFDRjtBQUVEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBK0lBakMsRUFBQUEsTUFBTSxDQUFDdUMsR0FBUCxDQUNFO0FBQ0VDLElBQUFBLElBQUksRUFBRyxHQUFFQyxrQkFBVyxJQUFHQyxnQ0FBeUIsaUJBRGxEO0FBRUVMLElBQUFBLFFBQVEsRUFBRTtBQUNSTSxNQUFBQSxNQUFNLEVBQUV6QyxxQkFBT0MsTUFBUCxDQUFjO0FBQ3BCOEIsUUFBQUEsWUFBWSxFQUFFL0IscUJBQU9JLE1BQVA7QUFETSxPQUFkO0FBREE7QUFGWixHQURGLEVBU0UsT0FBT3NDLE9BQVAsRUFBZ0JDLE9BQWhCLEVBQXlCQyxRQUF6QixLQUFxRjtBQUNuRixVQUFNQyxNQUFNLEdBQUdILE9BQU8sQ0FBQ0ksZUFBUixDQUF3QkMsUUFBeEIsQ0FBaUNDLFFBQWpDLENBQTBDTCxPQUExQyxDQUFmO0FBQ0EsUUFBSU0sTUFBSjs7QUFDQSxRQUFJO0FBQ0ZBLE1BQUFBLE1BQU0sR0FBRyxNQUFNSixNQUFNLENBQUNLLGlCQUFQLENBQXlCLGtDQUF6QixFQUE2RDtBQUMxRW5CLFFBQUFBLFlBQVksRUFBRVksT0FBTyxDQUFDRixNQUFSLENBQWVWO0FBRDZDLE9BQTdELENBQWY7QUFHQSxhQUFPYSxRQUFRLENBQUNPLEVBQVQsQ0FBWTtBQUNqQkMsUUFBQUEsSUFBSSxFQUFFO0FBQ0pDLFVBQUFBLEtBQUssRUFBRUMsTUFBTSxDQUFDQyxJQUFQLENBQVlOLE1BQVosRUFBb0JPLE1BRHZCO0FBRUpDLFVBQUFBLElBQUksRUFBRVI7QUFGRjtBQURXLE9BQVosQ0FBUDtBQU1ELEtBVkQsQ0FVRSxPQUFPUyxLQUFQLEVBQWM7QUFDZEMsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlDLElBQUksQ0FBQ0MsU0FBTCxDQUFlSixLQUFmLENBQVo7QUFDQSxhQUFPSyxhQUFhLENBQUNuQixRQUFELEVBQVdjLEtBQVgsQ0FBcEI7QUFDRDtBQUNGLEdBMUJIO0FBNkJBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF1RUE1RCxFQUFBQSxNQUFNLENBQUN1QyxHQUFQLENBQ0U7QUFDRUMsSUFBQUEsSUFBSSxFQUFHLEdBQUVDLGtCQUFXLElBQUdDLGdDQUF5QixzQkFEbEQ7QUFFRUwsSUFBQUEsUUFBUSxFQUFFO0FBQ1JNLE1BQUFBLE1BQU0sRUFBRXpDLHFCQUFPQyxNQUFQLENBQWM7QUFDcEI4QixRQUFBQSxZQUFZLEVBQUUvQixxQkFBT0ksTUFBUCxFQURNO0FBRXBCNEQsUUFBQUEsRUFBRSxFQUFFaEUscUJBQU9JLE1BQVA7QUFGZ0IsT0FBZDtBQURBO0FBRlosR0FERixFQVVFLE9BQU9zQyxPQUFQLEVBQWdCQyxPQUFoQixFQUF5QkMsUUFBekIsS0FBcUY7QUFDbkYsVUFBTUMsTUFBTSxHQUFHSCxPQUFPLENBQUNJLGVBQVIsQ0FBd0JDLFFBQXhCLENBQWlDQyxRQUFqQyxDQUEwQ0wsT0FBMUMsQ0FBZjtBQUNBLFFBQUlNLE1BQUo7O0FBQ0EsUUFBSTtBQUNGQSxNQUFBQSxNQUFNLEdBQUcsTUFBTUosTUFBTSxDQUFDSyxpQkFBUCxDQUF5QixpQ0FBekIsRUFBNEQ7QUFDekVuQixRQUFBQSxZQUFZLEVBQUVZLE9BQU8sQ0FBQ0YsTUFBUixDQUFlVixZQUQ0QztBQUV6RWlDLFFBQUFBLEVBQUUsRUFBRXJCLE9BQU8sQ0FBQ0YsTUFBUixDQUFldUI7QUFGc0QsT0FBNUQsQ0FBZjtBQUlBLGFBQU9wQixRQUFRLENBQUNPLEVBQVQsQ0FBWTtBQUFFQyxRQUFBQSxJQUFJLEVBQUVILE1BQU0sQ0FBQ04sT0FBTyxDQUFDRixNQUFSLENBQWV1QixFQUFoQjtBQUFkLE9BQVosQ0FBUDtBQUNELEtBTkQsQ0FNRSxPQUFPTixLQUFQLEVBQWM7QUFDZCxhQUFPSyxhQUFhLENBQUNuQixRQUFELEVBQVdjLEtBQVgsQ0FBcEI7QUFDRDtBQUNGLEdBdEJIO0FBeUJBOzs7O0FBR0E1RCxFQUFBQSxNQUFNLENBQUNtRSxNQUFQLENBQ0U7QUFDRTNCLElBQUFBLElBQUksRUFBRyxHQUFFQyxrQkFBVyxJQUFHQyxnQ0FBeUIsc0JBRGxEO0FBRUVMLElBQUFBLFFBQVEsRUFBRTtBQUNSTSxNQUFBQSxNQUFNLEVBQUV6QyxxQkFBT0MsTUFBUCxDQUFjO0FBQ3BCOEIsUUFBQUEsWUFBWSxFQUFFL0IscUJBQU9JLE1BQVAsRUFETTtBQUVwQjRELFFBQUFBLEVBQUUsRUFBRWhFLHFCQUFPSSxNQUFQLENBQWM7QUFDaEI4RCxVQUFBQSxTQUFTLEVBQUU7QUFESyxTQUFkO0FBRmdCLE9BQWQ7QUFEQTtBQUZaLEdBREYsRUFZRSxPQUFPeEIsT0FBUCxFQUFnQkMsT0FBaEIsRUFBeUJDLFFBQXpCLEtBQXFGO0FBQ25GLFVBQU1DLE1BQU0sR0FBR0gsT0FBTyxDQUFDSSxlQUFSLENBQXdCQyxRQUF4QixDQUFpQ0MsUUFBakMsQ0FBMENMLE9BQTFDLENBQWY7QUFDQSxRQUFJTSxNQUFKOztBQUNBLFFBQUk7QUFDRkEsTUFBQUEsTUFBTSxHQUFHLE1BQU1KLE1BQU0sQ0FBQ0ssaUJBQVAsQ0FBeUIsb0NBQXpCLEVBQStEO0FBQzVFbkIsUUFBQUEsWUFBWSxFQUFFWSxPQUFPLENBQUNGLE1BQVIsQ0FBZVYsWUFEK0M7QUFFNUVpQyxRQUFBQSxFQUFFLEVBQUVyQixPQUFPLENBQUNGLE1BQVIsQ0FBZXVCO0FBRnlELE9BQS9ELENBQWY7QUFJQSxhQUFPcEIsUUFBUSxDQUFDTyxFQUFULENBQVk7QUFDakJDLFFBQUFBLElBQUksRUFBRTtBQUNKZSxVQUFBQSxPQUFPLEVBQUVsQixNQUFNLENBQUNrQjtBQURaO0FBRFcsT0FBWixDQUFQO0FBS0QsS0FWRCxDQVVFLE9BQU9ULEtBQVAsRUFBYztBQUNkLGFBQU9LLGFBQWEsQ0FBQ25CLFFBQUQsRUFBV2MsS0FBWCxDQUFwQjtBQUNEO0FBQ0YsR0E1Qkg7QUErQkE7Ozs7Ozs7Ozs7O0FBVUE1RCxFQUFBQSxNQUFNLENBQUNzRSxJQUFQLENBQ0U7QUFDRTlCLElBQUFBLElBQUksRUFBRyxHQUFFQyxrQkFBVyxJQUFHQyxnQ0FBeUIsaUJBRGxEO0FBRUVMLElBQUFBLFFBQVEsRUFBRTtBQUNSTSxNQUFBQSxNQUFNLEVBQUV6QyxxQkFBT0MsTUFBUCxDQUFjO0FBQ3BCOEIsUUFBQUEsWUFBWSxFQUFFL0IscUJBQU9JLE1BQVA7QUFETSxPQUFkLENBREE7QUFJUmdELE1BQUFBLElBQUksRUFBRXBELHFCQUFPVSxHQUFQO0FBSkU7QUFGWixHQURGLEVBVUUsT0FBT2dDLE9BQVAsRUFBZ0JDLE9BQWhCLEVBQXlCQyxRQUF6QixLQUFxRjtBQUNuRixRQUFJO0FBQ0ZkLE1BQUFBLG1CQUFtQixDQUFDYSxPQUFPLENBQUNGLE1BQVIsQ0FBZVYsWUFBaEIsRUFBOEJZLE9BQU8sQ0FBQ1MsSUFBdEMsQ0FBbkI7QUFDRCxLQUZELENBRUUsT0FBT00sS0FBUCxFQUFjO0FBQ2QsYUFBT2QsUUFBUSxDQUFDeUIsVUFBVCxDQUFvQjtBQUFFakIsUUFBQUEsSUFBSSxFQUFFTTtBQUFSLE9BQXBCLENBQVA7QUFDRDs7QUFDRCxVQUFNYixNQUFNLEdBQUdILE9BQU8sQ0FBQ0ksZUFBUixDQUF3QkMsUUFBeEIsQ0FBaUNDLFFBQWpDLENBQTBDTCxPQUExQyxDQUFmO0FBQ0EsUUFBSU0sTUFBSjs7QUFDQSxRQUFJO0FBQ0ZBLE1BQUFBLE1BQU0sR0FBRyxNQUFNSixNQUFNLENBQUNLLGlCQUFQLENBQXlCLDJDQUF6QixFQUFzRTtBQUNuRm5CLFFBQUFBLFlBQVksRUFBRVksT0FBTyxDQUFDRixNQUFSLENBQWVWLFlBRHNEO0FBRW5GcUIsUUFBQUEsSUFBSSxFQUFFVCxPQUFPLENBQUNTO0FBRnFFLE9BQXRFLENBQWY7QUFJQSxhQUFPUixRQUFRLENBQUNPLEVBQVQsQ0FBWTtBQUNqQkMsUUFBQUEsSUFBSSxFQUFFO0FBQ0plLFVBQUFBLE9BQU8sRUFBRWxCLE1BQU0sQ0FBQ2tCO0FBRFo7QUFEVyxPQUFaLENBQVA7QUFLRCxLQVZELENBVUUsT0FBT1QsS0FBUCxFQUFjO0FBQ2QsYUFBT0ssYUFBYSxDQUFDbkIsUUFBRCxFQUFXYyxLQUFYLENBQXBCO0FBQ0Q7QUFDRixHQS9CSDtBQWtDQTs7OztBQUdBNUQsRUFBQUEsTUFBTSxDQUFDc0UsSUFBUCxDQUNFO0FBQ0U5QixJQUFBQSxJQUFJLEVBQUcsR0FBRUMsa0JBQVcsSUFBR0MsZ0NBQXlCLHNCQURsRDtBQUVFTCxJQUFBQSxRQUFRLEVBQUU7QUFDUk0sTUFBQUEsTUFBTSxFQUFFekMscUJBQU9DLE1BQVAsQ0FBYztBQUNwQjhCLFFBQUFBLFlBQVksRUFBRS9CLHFCQUFPSSxNQUFQLEVBRE07QUFFcEI0RCxRQUFBQSxFQUFFLEVBQUVoRSxxQkFBT0ksTUFBUCxDQUFjO0FBQ2hCK0IsVUFBQUEsUUFBUSxFQUFFQztBQURNLFNBQWQ7QUFGZ0IsT0FBZCxDQURBO0FBT1JnQixNQUFBQSxJQUFJLEVBQUVwRCxxQkFBT1UsR0FBUDtBQVBFO0FBRlosR0FERixFQWFFLE9BQU9nQyxPQUFQLEVBQWdCQyxPQUFoQixFQUF5QkMsUUFBekIsS0FBcUY7QUFDbkYsUUFBSTtBQUNGZCxNQUFBQSxtQkFBbUIsQ0FBQ2EsT0FBTyxDQUFDRixNQUFSLENBQWVWLFlBQWhCLEVBQThCWSxPQUFPLENBQUNTLElBQXRDLENBQW5CO0FBQ0QsS0FGRCxDQUVFLE9BQU9NLEtBQVAsRUFBYztBQUNkLGFBQU9kLFFBQVEsQ0FBQ3lCLFVBQVQsQ0FBb0I7QUFBRWpCLFFBQUFBLElBQUksRUFBRU07QUFBUixPQUFwQixDQUFQO0FBQ0Q7O0FBQ0QsVUFBTWIsTUFBTSxHQUFHSCxPQUFPLENBQUNJLGVBQVIsQ0FBd0JDLFFBQXhCLENBQWlDQyxRQUFqQyxDQUEwQ0wsT0FBMUMsQ0FBZjtBQUNBLFFBQUlNLE1BQUo7O0FBQ0EsUUFBSTtBQUNGQSxNQUFBQSxNQUFNLEdBQUcsTUFBTUosTUFBTSxDQUFDSyxpQkFBUCxDQUF5QixrQ0FBekIsRUFBNkQ7QUFDMUVuQixRQUFBQSxZQUFZLEVBQUVZLE9BQU8sQ0FBQ0YsTUFBUixDQUFlVixZQUQ2QztBQUUxRWlDLFFBQUFBLEVBQUUsRUFBRXJCLE9BQU8sQ0FBQ0YsTUFBUixDQUFldUIsRUFGdUQ7QUFHMUVaLFFBQUFBLElBQUksRUFBRVQsT0FBTyxDQUFDUztBQUg0RCxPQUE3RCxDQUFmO0FBS0EsYUFBT1IsUUFBUSxDQUFDTyxFQUFULENBQVk7QUFDakJDLFFBQUFBLElBQUksRUFBRTtBQUNKZSxVQUFBQSxPQUFPLEVBQUVsQixNQUFNLENBQUNrQjtBQURaO0FBRFcsT0FBWixDQUFQO0FBS0QsS0FYRCxDQVdFLE9BQU9ULEtBQVAsRUFBYztBQUNkLGFBQU9LLGFBQWEsQ0FBQ25CLFFBQUQsRUFBV2MsS0FBWCxDQUFwQjtBQUNEO0FBQ0YsR0FuQ0g7QUFzQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF3QkE1RCxFQUFBQSxNQUFNLENBQUN1QyxHQUFQLENBQ0U7QUFDRUMsSUFBQUEsSUFBSSxFQUFHLEdBQUVDLGtCQUFXLGdCQUR0QjtBQUVFSixJQUFBQSxRQUFRLEVBQUU7QUFGWixHQURGLEVBS0UsT0FBT08sT0FBUCxFQUFnQkMsT0FBaEIsRUFBeUJDLFFBQXpCLEtBQXFGO0FBQ25GLFVBQU1DLE1BQU0sR0FBR0gsT0FBTyxDQUFDSSxlQUFSLENBQXdCQyxRQUF4QixDQUFpQ0MsUUFBakMsQ0FBMENMLE9BQTFDLENBQWY7QUFDQSxRQUFJTSxNQUFKOztBQUNBLFFBQUk7QUFDRkEsTUFBQUEsTUFBTSxHQUFHLE1BQU1KLE1BQU0sQ0FBQ0ssaUJBQVAsQ0FBeUIsOEJBQXpCLENBQWY7QUFFQSxhQUFPTixRQUFRLENBQUNPLEVBQVQsQ0FBWTtBQUNqQkMsUUFBQUEsSUFBSSxFQUFFSDtBQURXLE9BQVosQ0FBUDtBQUdELEtBTkQsQ0FNRSxPQUFPUyxLQUFQLEVBQWM7QUFDZCxhQUFPSyxhQUFhLENBQUNuQixRQUFELEVBQVdjLEtBQVgsQ0FBcEI7QUFDRDtBQUNGLEdBakJIO0FBb0JBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQXVEQTVELEVBQUFBLE1BQU0sQ0FBQ3VDLEdBQVAsQ0FDRTtBQUNFQyxJQUFBQSxJQUFJLEVBQUcsR0FBRUMsa0JBQVcsc0JBRHRCO0FBRUVKLElBQUFBLFFBQVEsRUFBRTtBQUZaLEdBREYsRUFLRSxPQUFPTyxPQUFQLEVBQWdCQyxPQUFoQixFQUF5QkMsUUFBekIsS0FBcUY7QUFDbkYsVUFBTUMsTUFBTSxHQUFHSCxPQUFPLENBQUNJLGVBQVIsQ0FBd0JDLFFBQXhCLENBQWlDQyxRQUFqQyxDQUEwQ0wsT0FBMUMsQ0FBZjtBQUVBLFFBQUlNLE1BQUo7O0FBQ0EsUUFBSTtBQUNGQSxNQUFBQSxNQUFNLEdBQUcsTUFBTUosTUFBTSxDQUFDSyxpQkFBUCxDQUF5Qiw4QkFBekIsQ0FBZjtBQUVBLGFBQU9OLFFBQVEsQ0FBQ08sRUFBVCxDQUFZO0FBQ2pCQyxRQUFBQSxJQUFJLEVBQUVIO0FBRFcsT0FBWixDQUFQO0FBR0QsS0FORCxDQU1FLE9BQU9TLEtBQVAsRUFBYztBQUNkLGFBQU9kLFFBQVEsQ0FBQzBCLE1BQVQsQ0FBZ0I7QUFDckJDLFFBQUFBLFVBQVUsRUFBRWIsS0FBSyxDQUFDYSxVQURHO0FBRXJCbkIsUUFBQUEsSUFBSSxFQUFFb0Isb0JBQW9CLENBQUNkLEtBQUQ7QUFGTCxPQUFoQixDQUFQO0FBSUQ7QUFDRixHQXJCSDtBQXdCQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUF1REE1RCxFQUFBQSxNQUFNLENBQUNzRSxJQUFQLENBQ0U7QUFDRTlCLElBQUFBLElBQUksRUFBRyxHQUFFQyxrQkFBVyw2QkFEdEI7QUFFRUosSUFBQUEsUUFBUSxFQUFFO0FBQ1JpQixNQUFBQSxJQUFJLEVBQUVwRCxxQkFBT1UsR0FBUDtBQURFO0FBRlosR0FERixFQU9FLE9BQU9nQyxPQUFQLEVBQWdCQyxPQUFoQixFQUF5QkMsUUFBekIsS0FBc0M7QUFDcEMsVUFBTUMsTUFBTSxHQUFHSCxPQUFPLENBQUNJLGVBQVIsQ0FBd0JDLFFBQXhCLENBQWlDQyxRQUFqQyxDQUEwQ0wsT0FBMUMsQ0FBZjtBQUNBLFFBQUlNLE1BQUo7O0FBQ0EsUUFBSTtBQUNGQSxNQUFBQSxNQUFNLEdBQUcsTUFBTUosTUFBTSxDQUFDSyxpQkFBUCxDQUF5QiwrQkFBekIsRUFBMEQ7QUFDdkVFLFFBQUFBLElBQUksRUFBRVQsT0FBTyxDQUFDUztBQUR5RCxPQUExRCxDQUFmO0FBR0EsYUFBT1IsUUFBUSxDQUFDTyxFQUFULENBQVk7QUFDakJDLFFBQUFBLElBQUksRUFBRTtBQUNKZSxVQUFBQSxPQUFPLEVBQUVsQixNQUFNLENBQUNrQjtBQURaO0FBRFcsT0FBWixDQUFQO0FBS0QsS0FURCxDQVNFLE9BQU9ULEtBQVAsRUFBYztBQUNkLGFBQU9LLGFBQWEsQ0FBQ25CLFFBQUQsRUFBV2MsS0FBWCxDQUFwQjtBQUNEO0FBQ0YsR0F0Qkg7QUF5QkE7Ozs7OztBQUtBNUQsRUFBQUEsTUFBTSxDQUFDbUUsTUFBUCxDQUNFO0FBQ0UzQixJQUFBQSxJQUFJLEVBQUcsR0FBRUMsa0JBQVcsc0JBRHRCO0FBRUVKLElBQUFBLFFBQVEsRUFBRTtBQUZaLEdBREYsRUFLRSxPQUFPTyxPQUFQLEVBQWdCQyxPQUFoQixFQUF5QkMsUUFBekIsS0FBc0M7QUFDcEMsVUFBTUMsTUFBTSxHQUFHSCxPQUFPLENBQUNJLGVBQVIsQ0FBd0JDLFFBQXhCLENBQWlDQyxRQUFqQyxDQUEwQ0wsT0FBMUMsQ0FBZjtBQUNBLFFBQUk4QixVQUFKOztBQUNBLFFBQUk7QUFDRkEsTUFBQUEsVUFBVSxHQUFHLE1BQU01QixNQUFNLENBQUNLLGlCQUFQLENBQXlCLGdDQUF6QixDQUFuQjtBQUNBLGFBQU9OLFFBQVEsQ0FBQ08sRUFBVCxDQUFZO0FBQ2pCQyxRQUFBQSxJQUFJLEVBQUU7QUFDSmUsVUFBQUEsT0FBTyxFQUFFTSxVQUFVLENBQUNOO0FBRGhCO0FBRFcsT0FBWixDQUFQO0FBS0QsS0FQRCxDQU9FLE9BQU9ULEtBQVAsRUFBYztBQUNkLGFBQU9LLGFBQWEsQ0FBQ25CLFFBQUQsRUFBV2MsS0FBWCxDQUFwQjtBQUNEO0FBQ0YsR0FsQkg7QUFxQkE7Ozs7Ozs7Ozs7OztBQVdBNUQsRUFBQUEsTUFBTSxDQUFDdUMsR0FBUCxDQUNFO0FBQ0VDLElBQUFBLElBQUksRUFBRyxHQUFFQyxrQkFBVyxjQUR0QjtBQUVFSixJQUFBQSxRQUFRLEVBQUU7QUFGWixHQURGLEVBS0UsT0FBT08sT0FBUCxFQUFnQkMsT0FBaEIsRUFBeUJDLFFBQXpCLEtBQXNDO0FBQ3BDLFVBQU1DLE1BQU0sR0FBR0gsT0FBTyxDQUFDSSxlQUFSLENBQXdCQyxRQUF4QixDQUFpQ0MsUUFBakMsQ0FBMENMLE9BQTFDLENBQWY7O0FBQ0EsUUFBSTtBQUNGLFlBQU04QixVQUFVLEdBQUcsTUFBTTVCLE1BQU0sQ0FBQ0ssaUJBQVAsQ0FBeUIsaUNBQXpCLENBQXpCO0FBQ0EsYUFBT04sUUFBUSxDQUFDTyxFQUFULENBQVk7QUFDakJDLFFBQUFBLElBQUksRUFBRXFCO0FBRFcsT0FBWixDQUFQO0FBR0QsS0FMRCxDQUtFLE9BQU9mLEtBQVAsRUFBYztBQUNkLGFBQU9kLFFBQVEsQ0FBQ3lCLFVBQVQsQ0FBb0I7QUFDekJqQixRQUFBQSxJQUFJLEVBQUVNO0FBRG1CLE9BQXBCLENBQVA7QUFHRDtBQUNGLEdBakJIO0FBb0JBOzs7Ozs7QUFLQTVELEVBQUFBLE1BQU0sQ0FBQ3NFLElBQVAsQ0FDRTtBQUNFOUIsSUFBQUEsSUFBSSxFQUFHLEdBQUVDLGtCQUFXLElBQUdDLGdDQUF5QiwwQkFEbEQ7QUFFRUwsSUFBQUEsUUFBUSxFQUFFO0FBQ1JNLE1BQUFBLE1BQU0sRUFBRXpDLHFCQUFPQyxNQUFQLENBQWM7QUFDcEI7QUFDQXlFLFFBQUFBLFNBQVMsRUFBRTFFLHFCQUFPRyxLQUFQLENBQWFILHFCQUFPSSxNQUFQLEVBQWI7QUFGUyxPQUFkLENBREE7QUFLUmdELE1BQUFBLElBQUksRUFBRXBELHFCQUFPVSxHQUFQO0FBTEU7QUFGWixHQURGLEVBV0UsT0FBT2dDLE9BQVAsRUFBZ0JDLE9BQWhCLEVBQXlCQyxRQUF6QixLQUFzQztBQUNwQyxVQUFNQyxNQUFNLEdBQUdILE9BQU8sQ0FBQ0ksZUFBUixDQUF3QkMsUUFBeEIsQ0FBaUNDLFFBQWpDLENBQTBDTCxPQUExQyxDQUFmOztBQUNBLFFBQUk7QUFDRixZQUFNOEIsVUFBVSxHQUFHLE1BQU01QixNQUFNLENBQUNLLGlCQUFQLENBQXlCLGlDQUF6QixFQUE0RDtBQUNuRkUsUUFBQUEsSUFBSSxFQUFFVCxPQUFPLENBQUNTO0FBRHFFLE9BQTVELENBQXpCO0FBR0EsYUFBT1IsUUFBUSxDQUFDTyxFQUFULENBQVk7QUFDakJDLFFBQUFBLElBQUksRUFBRXFCO0FBRFcsT0FBWixDQUFQO0FBR0QsS0FQRCxDQU9FLE9BQU9mLEtBQVAsRUFBYztBQUNkLGFBQU9LLGFBQWEsQ0FBQ25CLFFBQUQsRUFBV2MsS0FBWCxDQUFwQjtBQUNEO0FBQ0YsR0F2Qkg7QUEwQkE7Ozs7Ozs7QUFNQTVELEVBQUFBLE1BQU0sQ0FBQ3NFLElBQVAsQ0FDRTtBQUNFOUIsSUFBQUEsSUFBSSxFQUFHLEdBQUVDLGtCQUFXLElBQUdDLGdDQUF5QixpQkFEbEQ7QUFFRUwsSUFBQUEsUUFBUSxFQUFFO0FBQ1JpQixNQUFBQSxJQUFJLEVBQUVwRCxxQkFBT0MsTUFBUCxDQUFjO0FBQ2xCMEUsUUFBQUEsS0FBSyxFQUFFM0UscUJBQU9PLE9BQVAsQ0FBZVAscUJBQU9JLE1BQVAsRUFBZjtBQURXLE9BQWQ7QUFERTtBQUZaLEdBREYsRUFTRSxPQUFPc0MsT0FBUCxFQUFnQkMsT0FBaEIsRUFBeUJDLFFBQXpCLEtBQXNDO0FBQ3BDLFVBQU1DLE1BQU0sR0FBR0gsT0FBTyxDQUFDSSxlQUFSLENBQXdCQyxRQUF4QixDQUFpQ0MsUUFBakMsQ0FBMENMLE9BQTFDLENBQWY7O0FBQ0EsUUFBSTtBQUNGLFlBQU04QixVQUFVLEdBQUcsTUFBTTVCLE1BQU0sQ0FBQ0ssaUJBQVAsQ0FBeUIsc0NBQXpCLEVBQWlFO0FBQ3hGeUIsUUFBQUEsS0FBSyxFQUFFaEMsT0FBTyxDQUFDUyxJQUFSLENBQWF1QixLQUFiLENBQW1CQyxJQUFuQixDQUF3QixHQUF4QixDQURpRjtBQUV4RkMsUUFBQUEsa0JBQWtCLEVBQUUsSUFGb0U7QUFHeEZDLFFBQUFBLGdCQUFnQixFQUFFO0FBSHNFLE9BQWpFLENBQXpCO0FBTUEsYUFBT2xDLFFBQVEsQ0FBQ08sRUFBVCxDQUFZO0FBQ2pCQyxRQUFBQSxJQUFJLEVBQUVxQjtBQURXLE9BQVosQ0FBUDtBQUdELEtBVkQsQ0FVRSxPQUFPZixLQUFQLEVBQWM7QUFDZCxhQUFPSyxhQUFhLENBQUNuQixRQUFELEVBQVdjLEtBQVgsQ0FBcEI7QUFDRDtBQUNGLEdBeEJIO0FBMkJBOzs7Ozs7O0FBTUE1RCxFQUFBQSxNQUFNLENBQUN1QyxHQUFQLENBQ0U7QUFDRUMsSUFBQUEsSUFBSSxFQUFHLEdBQUVDLGtCQUFXLElBQUdDLGdDQUF5QixVQURsRDtBQUVFTCxJQUFBQSxRQUFRLEVBQUU7QUFGWixHQURGLEVBS0UsT0FBT08sT0FBUCxFQUFnQkMsT0FBaEIsRUFBeUJDLFFBQXpCLEtBQXNDO0FBQ3BDLFVBQU1DLE1BQU0sR0FBR0gsT0FBTyxDQUFDSSxlQUFSLENBQXdCQyxRQUF4QixDQUFpQ0MsUUFBakMsQ0FBMENMLE9BQTFDLENBQWY7O0FBQ0EsUUFBSTtBQUNGLFlBQU04QixVQUFVLEdBQUcsTUFBTTVCLE1BQU0sQ0FBQ0ssaUJBQVAsQ0FBeUIsNkJBQXpCLENBQXpCO0FBQ0EsYUFBT04sUUFBUSxDQUFDTyxFQUFULENBQVk7QUFDakJDLFFBQUFBLElBQUksRUFBRXFCO0FBRFcsT0FBWixDQUFQO0FBR0QsS0FMRCxDQUtFLE9BQU9mLEtBQVAsRUFBYztBQUNkLGFBQU9LLGFBQWEsQ0FBQ25CLFFBQUQsRUFBV2MsS0FBWCxDQUFwQjtBQUNEO0FBQ0YsR0FmSDtBQWlCRDs7QUFFRCxTQUFTYyxvQkFBVCxDQUE4QmQsS0FBOUIsRUFBMEM7QUFDeEMsTUFBSUEsS0FBSyxDQUFDZCxRQUFWLEVBQW9CO0FBQ2xCLFFBQUk7QUFDRixZQUFNbUMsZUFBZSxHQUFHbEIsSUFBSSxDQUFDbUIsS0FBTCxDQUFXdEIsS0FBSyxDQUFDZCxRQUFqQixDQUF4QjtBQUNBLGFBQU9tQyxlQUFlLENBQUNFLE1BQWhCLElBQTBCdkIsS0FBSyxDQUFDZCxRQUF2QztBQUNELEtBSEQsQ0FHRSxPQUFPc0MsWUFBUCxFQUFxQjtBQUNyQixhQUFPeEIsS0FBSyxDQUFDZCxRQUFiO0FBQ0Q7QUFDRjs7QUFDRCxTQUFPYyxLQUFLLENBQUNTLE9BQWI7QUFDRDs7QUFFRCxTQUFTSixhQUFULENBQXVCbkIsUUFBdkIsRUFBd0RjLEtBQXhELEVBQW9FO0FBQ2xFLFNBQU9kLFFBQVEsQ0FBQzBCLE1BQVQsQ0FBZ0I7QUFDckJDLElBQUFBLFVBQVUsRUFBRWIsS0FBSyxDQUFDYSxVQURHO0FBRXJCbkIsSUFBQUEsSUFBSSxFQUFFb0Isb0JBQW9CLENBQUNkLEtBQUQ7QUFGTCxHQUFoQixDQUFQO0FBSUQiLCJzb3VyY2VzQ29udGVudCI6WyIvKlxuICogICBDb3B5cmlnaHQgMjAyMCBBbWF6b24uY29tLCBJbmMuIG9yIGl0cyBhZmZpbGlhdGVzLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICpcbiAqICAgTGljZW5zZWQgdW5kZXIgdGhlIEFwYWNoZSBMaWNlbnNlLCBWZXJzaW9uIDIuMCAodGhlIFwiTGljZW5zZVwiKS5cbiAqICAgWW91IG1heSBub3QgdXNlIHRoaXMgZmlsZSBleGNlcHQgaW4gY29tcGxpYW5jZSB3aXRoIHRoZSBMaWNlbnNlLlxuICogICBBIGNvcHkgb2YgdGhlIExpY2Vuc2UgaXMgbG9jYXRlZCBhdFxuICpcbiAqICAgICAgIGh0dHA6Ly93d3cuYXBhY2hlLm9yZy9saWNlbnNlcy9MSUNFTlNFLTIuMFxuICpcbiAqICAgb3IgaW4gdGhlIFwibGljZW5zZVwiIGZpbGUgYWNjb21wYW55aW5nIHRoaXMgZmlsZS4gVGhpcyBmaWxlIGlzIGRpc3RyaWJ1dGVkXG4gKiAgIG9uIGFuIFwiQVMgSVNcIiBCQVNJUywgV0lUSE9VVCBXQVJSQU5USUVTIE9SIENPTkRJVElPTlMgT0YgQU5ZIEtJTkQsIGVpdGhlclxuICogICBleHByZXNzIG9yIGltcGxpZWQuIFNlZSB0aGUgTGljZW5zZSBmb3IgdGhlIHNwZWNpZmljIGxhbmd1YWdlIGdvdmVybmluZ1xuICogICBwZXJtaXNzaW9ucyBhbmQgbGltaXRhdGlvbnMgdW5kZXIgdGhlIExpY2Vuc2UuXG4gKi9cblxuaW1wb3J0IHsgc2NoZW1hIH0gZnJvbSAnQGtibi9jb25maWctc2NoZW1hJztcbmltcG9ydCB7IElSb3V0ZXIsIFJlc3BvbnNlRXJyb3IsIElLaWJhbmFSZXNwb25zZSwgS2liYW5hUmVzcG9uc2VGYWN0b3J5IH0gZnJvbSAna2liYW5hL3NlcnZlcic7XG5pbXBvcnQgeyBBUElfUFJFRklYLCBDT05GSUdVUkFUSU9OX0FQSV9QUkVGSVgsIGlzVmFsaWRSZXNvdXJjZU5hbWUgfSBmcm9tICcuLi8uLi9jb21tb24nO1xuXG4vLyBUT0RPOiBjb25zaWRlciB0byBleHRyYWN0IGVudGl0eSBDUlVEIG9wZXJhdGlvbnMgYW5kIHB1dCBpdCBpbnRvIGEgY2xpZW50IGNsYXNzXG5leHBvcnQgZnVuY3Rpb24gZGVmaW5lUm91dGVzKHJvdXRlcjogSVJvdXRlcikge1xuICBjb25zdCBpbnRlcm5hbFVzZXJTY2hlbWEgPSBzY2hlbWEub2JqZWN0KHtcbiAgICBkZXNjcmlwdGlvbjogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgcGFzc3dvcmQ6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICBiYWNrZW5kX3JvbGVzOiBzY2hlbWEuYXJyYXlPZihzY2hlbWEuc3RyaW5nKCksIHsgZGVmYXVsdFZhbHVlOiBbXSB9KSxcbiAgICBhdHRyaWJ1dGVzOiBzY2hlbWEuYW55KHsgZGVmYXVsdFZhbHVlOiB7fSB9KSxcbiAgfSk7XG5cbiAgY29uc3QgYWN0aW9uR3JvdXBTY2hlbWEgPSBzY2hlbWEub2JqZWN0KHtcbiAgICBkZXNjcmlwdGlvbjogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgYWxsb3dlZF9hY3Rpb25zOiBzY2hlbWEuYXJyYXlPZihzY2hlbWEuc3RyaW5nKCkpLFxuICAgIC8vIHR5cGUgZmllbGQgaXMgbm90IHN1cHBvcnRlZCBpbiBsZWdhY3kgaW1wbGVtZW50YXRpb24sIGNvbW1lbnQgaXQgb3V0IGZvciBub3cuXG4gICAgLy8gdHlwZTogc2NoZW1hLm9uZU9mKFtcbiAgICAvLyAgIHNjaGVtYS5saXRlcmFsKCdjbHVzdGVyJyksXG4gICAgLy8gICBzY2hlbWEubGl0ZXJhbCgnaW5kZXgnKSxcbiAgICAvLyAgIHNjaGVtYS5saXRlcmFsKCdraWJhbmEnKSxcbiAgICAvLyBdKSxcbiAgfSk7XG5cbiAgY29uc3Qgcm9sZU1hcHBpbmdTY2hlbWEgPSBzY2hlbWEub2JqZWN0KHtcbiAgICBkZXNjcmlwdGlvbjogc2NoZW1hLm1heWJlKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgYmFja2VuZF9yb2xlczogc2NoZW1hLmFycmF5T2Yoc2NoZW1hLnN0cmluZygpLCB7IGRlZmF1bHRWYWx1ZTogW10gfSksXG4gICAgaG9zdHM6IHNjaGVtYS5hcnJheU9mKHNjaGVtYS5zdHJpbmcoKSwgeyBkZWZhdWx0VmFsdWU6IFtdIH0pLFxuICAgIHVzZXJzOiBzY2hlbWEuYXJyYXlPZihzY2hlbWEuc3RyaW5nKCksIHsgZGVmYXVsdFZhbHVlOiBbXSB9KSxcbiAgfSk7XG5cbiAgY29uc3Qgcm9sZVNjaGVtYSA9IHNjaGVtYS5vYmplY3Qoe1xuICAgIGRlc2NyaXB0aW9uOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICBjbHVzdGVyX3Blcm1pc3Npb25zOiBzY2hlbWEuYXJyYXlPZihzY2hlbWEuc3RyaW5nKCksIHsgZGVmYXVsdFZhbHVlOiBbXSB9KSxcbiAgICB0ZW5hbnRfcGVybWlzc2lvbnM6IHNjaGVtYS5hcnJheU9mKHNjaGVtYS5hbnkoKSwgeyBkZWZhdWx0VmFsdWU6IFtdIH0pLFxuICAgIGluZGV4X3Blcm1pc3Npb25zOiBzY2hlbWEuYXJyYXlPZihzY2hlbWEuYW55KCksIHsgZGVmYXVsdFZhbHVlOiBbXSB9KSxcbiAgfSk7XG5cbiAgY29uc3QgdGVuYW50U2NoZW1hID0gc2NoZW1hLm9iamVjdCh7XG4gICAgZGVzY3JpcHRpb246IHNjaGVtYS5zdHJpbmcoKSxcbiAgfSk7XG5cbiAgY29uc3QgYWNjb3VudFNjaGVtYSA9IHNjaGVtYS5vYmplY3Qoe1xuICAgIHBhc3N3b3JkOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgY3VycmVudF9wYXNzd29yZDogc2NoZW1hLnN0cmluZygpLFxuICB9KTtcblxuICBjb25zdCBzY2hlbWFNYXA6IGFueSA9IHtcbiAgICBpbnRlcm5hbHVzZXJzOiBpbnRlcm5hbFVzZXJTY2hlbWEsXG4gICAgYWN0aW9uZ3JvdXBzOiBhY3Rpb25Hcm91cFNjaGVtYSxcbiAgICByb2xlc21hcHBpbmc6IHJvbGVNYXBwaW5nU2NoZW1hLFxuICAgIHJvbGVzOiByb2xlU2NoZW1hLFxuICAgIHRlbmFudHM6IHRlbmFudFNjaGVtYSxcbiAgICBhY2NvdW50OiBhY2NvdW50U2NoZW1hLFxuICB9O1xuXG4gIGZ1bmN0aW9uIHZhbGlkYXRlUmVxdWVzdEJvZHkocmVzb3VyY2VOYW1lOiBzdHJpbmcsIHJlcXVlc3RCb2R5OiBhbnkpOiBhbnkge1xuICAgIGNvbnN0IGlucHV0U2NoZW1hID0gc2NoZW1hTWFwW3Jlc291cmNlTmFtZV07XG4gICAgaWYgKCFpbnB1dFNjaGVtYSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGBVbmtub3duIHJlc291cmNlICR7cmVzb3VyY2VOYW1lfWApO1xuICAgIH1cbiAgICBpbnB1dFNjaGVtYS52YWxpZGF0ZShyZXF1ZXN0Qm9keSk7IC8vIHRocm93cyBlcnJvciBpZiB2YWxpZGF0aW9uIGZhaWxcbiAgfVxuXG4gIGZ1bmN0aW9uIHZhbGlkYXRlRW50aXR5SWQocmVzb3VyY2VOYW1lOiBzdHJpbmcpIHtcbiAgICBpZiAoIWlzVmFsaWRSZXNvdXJjZU5hbWUocmVzb3VyY2VOYW1lKSkge1xuICAgICAgcmV0dXJuICdJbnZhbGlkIGVudGl0eSBuYW1lIG9yIGlkLic7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIExpc3RzIHJlc291cmNlcyBieSByZXNvdXJjZSBuYW1lLlxuICAgKlxuICAgKiBUaGUgcmVzcG9uc2UgZm9ybWF0IGlzOlxuICAgKiB7XG4gICAqICAgXCJ0b3RhbFwiOiA8dG90YWxfZW50aXR5X2NvdW50PixcbiAgICogICBcImRhdGFcIjoge1xuICAgKiAgICAgXCJlbnRpdHlfaWRfMVwiOiB7IDxlbnRpdHlfc3RydWN0dXJlPiB9LFxuICAgKiAgICAgXCJlbnRpdHlfaWRfMlwiOiB7IDxlbnRpdHlfc3RydWN0dXJlPiB9LFxuICAgKiAgICAgLi4uXG4gICAqICAgfVxuICAgKiB9XG4gICAqXG4gICAqIGUuZy4gd2hlbiBsaXN0aW5nIGludGVybmFsIHVzZXJzLCByZXNwb25zZSBtYXkgbG9vayBsaWtlOlxuICAgKiB7XG4gICAqICAgXCJ0b3RhbFwiOiAyLFxuICAgKiAgIFwiZGF0YVwiOiB7XG4gICAqICAgICBcImFwaV90ZXN0X3VzZXIyXCI6IHtcbiAgICogICAgICAgXCJoYXNoXCI6IFwiXCIsXG4gICAqICAgICAgIFwicmVzZXJ2ZWRcIjogZmFsc2UsXG4gICAqICAgICAgIFwiaGlkZGVuXCI6IGZhbHNlLFxuICAgKiAgICAgICBcImJhY2tlbmRfcm9sZXNcIjogW10sXG4gICAqICAgICAgIFwiYXR0cmlidXRlc1wiOiB7fSxcbiAgICogICAgICAgXCJkZXNjcmlwdGlvblwiOiBcIlwiLFxuICAgKiAgICAgICBcInN0YXRpY1wiOiBmYWxzZVxuICAgKiAgICAgfSxcbiAgICogICAgIFwiYXBpX3Rlc3RfdXNlcjFcIjoge1xuICAgKiAgICAgICBcImhhc2hcIjogXCJcIixcbiAgICogICAgICAgXCJyZXNlcnZlZFwiOiBmYWxzZSxcbiAgICogICAgICAgXCJoaWRkZW5cIjogZmFsc2UsXG4gICAqICAgICAgIFwiYmFja2VuZF9yb2xlc1wiOiBbXSxcbiAgICogICAgICAgXCJhdHRyaWJ1dGVzXCI6IHt9LFxuICAgKiAgICAgICBcInN0YXRpY1wiOiBmYWxzZVxuICAgKiAgICAgfVxuICAgKiB9XG4gICAqXG4gICAqIHdoZW4gbGlzdGluZyBhY3Rpb24gZ3JvdXBzLCByZXNwb25zZSB3aWxsIGxvb2sgbGlrZTpcbiAgICoge1xuICAgKiAgIFwidG90YWxcIjogMixcbiAgICogICBcImRhdGFcIjoge1xuICAgKiAgICAgXCJyZWFkXCI6IHtcbiAgICogICAgICAgXCJyZXNlcnZlZFwiOiB0cnVlLFxuICAgKiAgICAgICBcImhpZGRlblwiOiBmYWxzZSxcbiAgICogICAgICAgXCJhbGxvd2VkX2FjdGlvbnNcIjogW1wiaW5kaWNlczpkYXRhL3JlYWQqXCIsIFwiaW5kaWNlczphZG1pbi9tYXBwaW5ncy9maWVsZHMvZ2V0KlwiXSxcbiAgICogICAgICAgXCJ0eXBlXCI6IFwiaW5kZXhcIixcbiAgICogICAgICAgXCJkZXNjcmlwdGlvblwiOiBcIkFsbG93IGFsbCByZWFkIG9wZXJhdGlvbnNcIixcbiAgICogICAgICAgXCJzdGF0aWNcIjogZmFsc2VcbiAgICogICAgIH0sXG4gICAqICAgICBcImNsdXN0ZXJfYWxsXCI6IHtcbiAgICogICAgICAgXCJyZXNlcnZlZFwiOiB0cnVlLFxuICAgKiAgICAgICBcImhpZGRlblwiOiBmYWxzZSxcbiAgICogICAgICAgXCJhbGxvd2VkX2FjdGlvbnNcIjogW1wiY2x1c3RlcjoqXCJdLFxuICAgKiAgICAgICBcInR5cGVcIjogXCJjbHVzdGVyXCIsXG4gICAqICAgICAgIFwiZGVzY3JpcHRpb25cIjogXCJBbGxvdyBldmVyeXRoaW5nIG9uIGNsdXN0ZXIgbGV2ZWxcIixcbiAgICogICAgICAgXCJzdGF0aWNcIjogZmFsc2VcbiAgICogICAgIH1cbiAgICogfVxuICAgKlxuICAgKiByb2xlOlxuICAgKiB7XG4gICAqICAgXCJ0b3RhbFwiOiAyLFxuICAgKiAgIFwiZGF0YVwiOiB7XG4gICAqICAgICBcImtpYmFuYV91c2VyXCI6IHtcbiAgICogICAgICAgXCJyZXNlcnZlZFwiOiB0cnVlLFxuICAgKiAgICAgICBcImhpZGRlblwiOiBmYWxzZSxcbiAgICogICAgICAgXCJkZXNjcmlwdGlvblwiOiBcIlByb3ZpZGUgdGhlIG1pbmltdW0gcGVybWlzc2lvbnMgZm9yIGEga2liYW5hIHVzZXJcIixcbiAgICogICAgICAgXCJjbHVzdGVyX3Blcm1pc3Npb25zXCI6IFtcImNsdXN0ZXJfY29tcG9zaXRlX29wc1wiXSxcbiAgICogICAgICAgXCJpbmRleF9wZXJtaXNzaW9uc1wiOiBbe1xuICAgKiAgICAgICAgIFwiaW5kZXhfcGF0dGVybnNcIjogW1wiLmtpYmFuYVwiLCBcIi5raWJhbmEtNlwiLCBcIi5raWJhbmFfKlwiXSxcbiAgICogICAgICAgICBcImZsc1wiOiBbXSxcbiAgICogICAgICAgICBcIm1hc2tlZF9maWVsZHNcIjogW10sXG4gICAqICAgICAgICAgXCJhbGxvd2VkX2FjdGlvbnNcIjogW1wicmVhZFwiLCBcImRlbGV0ZVwiLCBcIm1hbmFnZVwiLCBcImluZGV4XCJdXG4gICAqICAgICAgIH0sIHtcbiAgICogICAgICAgICBcImluZGV4X3BhdHRlcm5zXCI6IFtcIi50YXNrc1wiLCBcIi5tYW5hZ2VtZW50LWJlYXRzXCJdLFxuICAgKiAgICAgICAgIFwiZmxzXCI6IFtdLFxuICAgKiAgICAgICAgIFwibWFza2VkX2ZpZWxkc1wiOiBbXSxcbiAgICogICAgICAgICBcImFsbG93ZWRfYWN0aW9uc1wiOiBbXCJpbmRpY2VzX2FsbFwiXVxuICAgKiAgICAgICB9XSxcbiAgICogICAgICAgXCJ0ZW5hbnRfcGVybWlzc2lvbnNcIjogW10sXG4gICAqICAgICAgIFwic3RhdGljXCI6IGZhbHNlXG4gICAqICAgICB9LFxuICAgKiAgICAgXCJhbGxfYWNjZXNzXCI6IHtcbiAgICogICAgICAgXCJyZXNlcnZlZFwiOiB0cnVlLFxuICAgKiAgICAgICBcImhpZGRlblwiOiBmYWxzZSxcbiAgICogICAgICAgXCJkZXNjcmlwdGlvblwiOiBcIkFsbG93IGZ1bGwgYWNjZXNzIHRvIGFsbCBpbmRpY2VzIGFuZCBhbGwgY2x1c3RlciBBUElzXCIsXG4gICAqICAgICAgIFwiY2x1c3Rlcl9wZXJtaXNzaW9uc1wiOiBbXCIqXCJdLFxuICAgKiAgICAgICBcImluZGV4X3Blcm1pc3Npb25zXCI6IFt7XG4gICAqICAgICAgICAgXCJpbmRleF9wYXR0ZXJuc1wiOiBbXCIqXCJdLFxuICAgKiAgICAgICAgIFwiZmxzXCI6IFtdLFxuICAgKiAgICAgICAgIFwibWFza2VkX2ZpZWxkc1wiOiBbXSxcbiAgICogICAgICAgICBcImFsbG93ZWRfYWN0aW9uc1wiOiBbXCIqXCJdXG4gICAqICAgICAgIH1dLFxuICAgKiAgICAgICBcInRlbmFudF9wZXJtaXNzaW9uc1wiOiBbe1xuICAgKiAgICAgICAgIFwidGVuYW50X3BhdHRlcm5zXCI6IFtcIipcIl0sXG4gICAqICAgICAgICAgXCJhbGxvd2VkX2FjdGlvbnNcIjogW1wia2liYW5hX2FsbF93cml0ZVwiXVxuICAgKiAgICAgICB9XSxcbiAgICogICAgICAgXCJzdGF0aWNcIjogZmFsc2VcbiAgICogICAgIH1cbiAgICogICB9XG4gICAqIH1cbiAgICpcbiAgICogcm9sZXNtYXBwaW5nOlxuICAgKiB7XG4gICAqICAgXCJ0b3RhbFwiOiAyLFxuICAgKiAgIFwiZGF0YVwiOiB7XG4gICAqICAgICBcInNlY3VyaXR5X21hbmFnZXJcIjoge1xuICAgKiAgICAgICBcInJlc2VydmVkXCI6IGZhbHNlLFxuICAgKiAgICAgICBcImhpZGRlblwiOiBmYWxzZSxcbiAgICogICAgICAgXCJiYWNrZW5kX3JvbGVzXCI6IFtdLFxuICAgKiAgICAgICBcImhvc3RzXCI6IFtdLFxuICAgKiAgICAgICBcInVzZXJzXCI6IFtcInplbmd5YW5cIiwgXCJhZG1pblwiXSxcbiAgICogICAgICAgXCJhbmRfYmFja2VuZF9yb2xlc1wiOiBbXVxuICAgKiAgICAgfSxcbiAgICogICAgIFwiYWxsX2FjY2Vzc1wiOiB7XG4gICAqICAgICAgIFwicmVzZXJ2ZWRcIjogZmFsc2UsXG4gICAqICAgICAgIFwiaGlkZGVuXCI6IGZhbHNlLFxuICAgKiAgICAgICBcImJhY2tlbmRfcm9sZXNcIjogW10sXG4gICAqICAgICAgIFwiaG9zdHNcIjogW10sXG4gICAqICAgICAgIFwidXNlcnNcIjogW1wiemVuZ3lhblwiLCBcImFkbWluXCIsIFwiaW5kZXh0ZXN0XCJdLFxuICAgKiAgICAgICBcImFuZF9iYWNrZW5kX3JvbGVzXCI6IFtdXG4gICAqICAgICB9XG4gICAqICAgfVxuICAgKiB9XG4gICAqXG4gICAqIHRlbmFudHM6XG4gICAqIHtcbiAgICogICBcInRvdGFsXCI6IDIsXG4gICAqICAgXCJkYXRhXCI6IHtcbiAgICogICAgIFwiZ2xvYmFsX3RlbmFudFwiOiB7XG4gICAqICAgICAgIFwicmVzZXJ2ZWRcIjogdHJ1ZSxcbiAgICogICAgICAgXCJoaWRkZW5cIjogZmFsc2UsXG4gICAqICAgICAgIFwiZGVzY3JpcHRpb25cIjogXCJHbG9iYWwgdGVuYW50XCIsXG4gICAqICAgICAgIFwic3RhdGljXCI6IGZhbHNlXG4gICAqICAgICB9LFxuICAgKiAgICAgXCJ0ZXN0IHRlbmFudFwiOiB7XG4gICAqICAgICAgIFwicmVzZXJ2ZWRcIjogZmFsc2UsXG4gICAqICAgICAgIFwiaGlkZGVuXCI6IGZhbHNlLFxuICAgKiAgICAgICBcImRlc2NyaXB0aW9uXCI6IFwidGVuYW50IGRlc2NyaXB0aW9uXCIsXG4gICAqICAgICAgIFwic3RhdGljXCI6IGZhbHNlXG4gICAqICAgICB9XG4gICAqICAgfVxuICAgKiB9XG4gICAqL1xuICByb3V0ZXIuZ2V0KFxuICAgIHtcbiAgICAgIHBhdGg6IGAke0FQSV9QUkVGSVh9LyR7Q09ORklHVVJBVElPTl9BUElfUFJFRklYfS97cmVzb3VyY2VOYW1lfWAsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBwYXJhbXM6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIHJlc291cmNlTmFtZTogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICB9KSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpOiBQcm9taXNlPElLaWJhbmFSZXNwb25zZTxhbnkgfCBSZXNwb25zZUVycm9yPj4gPT4ge1xuICAgICAgY29uc3QgY2xpZW50ID0gY29udGV4dC5zZWN1cml0eV9wbHVnaW4uZXNDbGllbnQuYXNTY29wZWQocmVxdWVzdCk7XG4gICAgICBsZXQgZXNSZXNwO1xuICAgICAgdHJ5IHtcbiAgICAgICAgZXNSZXNwID0gYXdhaXQgY2xpZW50LmNhbGxBc0N1cnJlbnRVc2VyKCdvcGVuZGlzdHJvX3NlY3VyaXR5Lmxpc3RSZXNvdXJjZScsIHtcbiAgICAgICAgICByZXNvdXJjZU5hbWU6IHJlcXVlc3QucGFyYW1zLnJlc291cmNlTmFtZSxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgdG90YWw6IE9iamVjdC5rZXlzKGVzUmVzcCkubGVuZ3RoLFxuICAgICAgICAgICAgZGF0YTogZXNSZXNwLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgY29uc29sZS5sb2coSlNPTi5zdHJpbmdpZnkoZXJyb3IpKTtcbiAgICAgICAgcmV0dXJuIGVycm9yUmVzcG9uc2UocmVzcG9uc2UsIGVycm9yKTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgLyoqXG4gICAqIEdldHMgZW50aXR5IGJ5IGlkLlxuICAgKlxuICAgKiB0aGUgcmVzcG9uc2UgZm9ybWF0IGRpZmZlcnMgZnJvbSBkaWZmZXJlbnQgcmVzb3VyY2UgdHlwZXMuIGUuZy5cbiAgICpcbiAgICogZm9yIGludGVybmFsIHVzZXIsIHJlc3BvbnNlIHdpbGwgbG9vayBsaWtlOlxuICAgKiB7XG4gICAqICAgXCJoYXNoXCI6IFwiXCIsXG4gICAqICAgXCJyZXNlcnZlZFwiOiBmYWxzZSxcbiAgICogICBcImhpZGRlblwiOiBmYWxzZSxcbiAgICogICBcImJhY2tlbmRfcm9sZXNcIjogW10sXG4gICAqICAgXCJhdHRyaWJ1dGVzXCI6IHt9LFxuICAgKiAgIFwic3RhdGljXCI6IGZhbHNlXG4gICAqIH1cbiAgICpcbiAgICogZm9yIHJvbGUsIHJlc3BvbnNlIHdpbGwgbG9vayBsaWtlOlxuICAgKiB7XG4gICAqICAgXCJyZXNlcnZlZFwiOiB0cnVlLFxuICAgKiAgIFwiaGlkZGVuXCI6IGZhbHNlLFxuICAgKiAgIFwiZGVzY3JpcHRpb25cIjogXCJBbGxvdyBmdWxsIGFjY2VzcyB0byBhbGwgaW5kaWNlcyBhbmQgYWxsIGNsdXN0ZXIgQVBJc1wiLFxuICAgKiAgIFwiY2x1c3Rlcl9wZXJtaXNzaW9uc1wiOiBbXCIqXCJdLFxuICAgKiAgIFwiaW5kZXhfcGVybWlzc2lvbnNcIjogW3tcbiAgICogICAgIFwiaW5kZXhfcGF0dGVybnNcIjogW1wiKlwiXSxcbiAgICogICAgIFwiZmxzXCI6IFtdLFxuICAgKiAgICAgXCJtYXNrZWRfZmllbGRzXCI6IFtdLFxuICAgKiAgICAgXCJhbGxvd2VkX2FjdGlvbnNcIjogW1wiKlwiXVxuICAgKiAgIH1dLFxuICAgKiAgIFwidGVuYW50X3Blcm1pc3Npb25zXCI6IFt7XG4gICAqICAgICBcInRlbmFudF9wYXR0ZXJuc1wiOiBbXCIqXCJdLFxuICAgKiAgICAgXCJhbGxvd2VkX2FjdGlvbnNcIjogW1wia2liYW5hX2FsbF93cml0ZVwiXVxuICAgKiAgIH1dLFxuICAgKiAgIFwic3RhdGljXCI6IGZhbHNlXG4gICAqIH1cbiAgICpcbiAgICogZm9yIHJvbGVzIG1hcHBpbmcsIHJlc3BvbnNlIHdpbGwgbG9vayBsaWtlOlxuICAgKiB7XG4gICAqICAgXCJyZXNlcnZlZFwiOiB0cnVlLFxuICAgKiAgIFwiaGlkZGVuXCI6IGZhbHNlLFxuICAgKiAgIFwiZGVzY3JpcHRpb25cIjogXCJBbGxvdyBmdWxsIGFjY2VzcyB0byBhbGwgaW5kaWNlcyBhbmQgYWxsIGNsdXN0ZXIgQVBJc1wiLFxuICAgKiAgIFwiY2x1c3Rlcl9wZXJtaXNzaW9uc1wiOiBbXCIqXCJdLFxuICAgKiAgIFwiaW5kZXhfcGVybWlzc2lvbnNcIjogW3tcbiAgICogICAgIFwiaW5kZXhfcGF0dGVybnNcIjogW1wiKlwiXSxcbiAgICogICAgIFwiZmxzXCI6IFtdLFxuICAgKiAgICAgXCJtYXNrZWRfZmllbGRzXCI6IFtdLFxuICAgKiAgICAgXCJhbGxvd2VkX2FjdGlvbnNcIjogW1wiKlwiXVxuICAgKiAgIH1dLFxuICAgKiAgIFwidGVuYW50X3Blcm1pc3Npb25zXCI6IFt7XG4gICAqICAgICBcInRlbmFudF9wYXR0ZXJuc1wiOiBbXCIqXCJdLFxuICAgKiAgICAgXCJhbGxvd2VkX2FjdGlvbnNcIjogW1wia2liYW5hX2FsbF93cml0ZVwiXVxuICAgKiAgIH1dLFxuICAgKiAgIFwic3RhdGljXCI6IGZhbHNlXG4gICAqIH1cbiAgICpcbiAgICogZm9yIGFjdGlvbiBncm91cHMsIHJlc3BvbnNlIHdpbGwgbG9vayBsaWtlOlxuICAgKiB7XG4gICAqICAgXCJyZXNlcnZlZFwiOiB0cnVlLFxuICAgKiAgIFwiaGlkZGVuXCI6IGZhbHNlLFxuICAgKiAgIFwiYWxsb3dlZF9hY3Rpb25zXCI6IFtcImluZGljZXM6ZGF0YS9yZWFkKlwiLCBcImluZGljZXM6YWRtaW4vbWFwcGluZ3MvZmllbGRzL2dldCpcIl0sXG4gICAqICAgXCJ0eXBlXCI6IFwiaW5kZXhcIixcbiAgICogICBcImRlc2NyaXB0aW9uXCI6IFwiQWxsb3cgYWxsIHJlYWQgb3BlcmF0aW9uc1wiLFxuICAgKiAgIFwic3RhdGljXCI6IGZhbHNlXG4gICAqIH1cbiAgICpcbiAgICogZm9yIHRlbmFudCwgcmVzcG9uc2Ugd2lsbCBsb29rIGxpa2U6XG4gICAqIHtcbiAgICogICBcInJlc2VydmVkXCI6IHRydWUsXG4gICAqICAgXCJoaWRkZW5cIjogZmFsc2UsXG4gICAqICAgXCJkZXNjcmlwdGlvblwiOiBcIkdsb2JhbCB0ZW5hbnRcIixcbiAgICogICBcInN0YXRpY1wiOiBmYWxzZVxuICAgKiB9LFxuICAgKi9cbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiBgJHtBUElfUFJFRklYfS8ke0NPTkZJR1VSQVRJT05fQVBJX1BSRUZJWH0ve3Jlc291cmNlTmFtZX0ve2lkfWAsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBwYXJhbXM6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIHJlc291cmNlTmFtZTogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICAgIGlkOiBzY2hlbWEuc3RyaW5nKCksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSk6IFByb21pc2U8SUtpYmFuYVJlc3BvbnNlPGFueSB8IFJlc3BvbnNlRXJyb3I+PiA9PiB7XG4gICAgICBjb25zdCBjbGllbnQgPSBjb250ZXh0LnNlY3VyaXR5X3BsdWdpbi5lc0NsaWVudC5hc1Njb3BlZChyZXF1ZXN0KTtcbiAgICAgIGxldCBlc1Jlc3A7XG4gICAgICB0cnkge1xuICAgICAgICBlc1Jlc3AgPSBhd2FpdCBjbGllbnQuY2FsbEFzQ3VycmVudFVzZXIoJ29wZW5kaXN0cm9fc2VjdXJpdHkuZ2V0UmVzb3VyY2UnLCB7XG4gICAgICAgICAgcmVzb3VyY2VOYW1lOiByZXF1ZXN0LnBhcmFtcy5yZXNvdXJjZU5hbWUsXG4gICAgICAgICAgaWQ6IHJlcXVlc3QucGFyYW1zLmlkLFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHsgYm9keTogZXNSZXNwW3JlcXVlc3QucGFyYW1zLmlkXSB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHJldHVybiBlcnJvclJlc3BvbnNlKHJlc3BvbnNlLCBlcnJvcik7XG4gICAgICB9XG4gICAgfVxuICApO1xuXG4gIC8qKlxuICAgKiBEZWxldGVzIGFuIGVudGl0eSBieSBpZC5cbiAgICovXG4gIHJvdXRlci5kZWxldGUoXG4gICAge1xuICAgICAgcGF0aDogYCR7QVBJX1BSRUZJWH0vJHtDT05GSUdVUkFUSU9OX0FQSV9QUkVGSVh9L3tyZXNvdXJjZU5hbWV9L3tpZH1gLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgcGFyYW1zOiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICByZXNvdXJjZU5hbWU6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgICBpZDogc2NoZW1hLnN0cmluZyh7XG4gICAgICAgICAgICBtaW5MZW5ndGg6IDEsXG4gICAgICAgICAgfSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSk6IFByb21pc2U8SUtpYmFuYVJlc3BvbnNlPGFueSB8IFJlc3BvbnNlRXJyb3I+PiA9PiB7XG4gICAgICBjb25zdCBjbGllbnQgPSBjb250ZXh0LnNlY3VyaXR5X3BsdWdpbi5lc0NsaWVudC5hc1Njb3BlZChyZXF1ZXN0KTtcbiAgICAgIGxldCBlc1Jlc3A7XG4gICAgICB0cnkge1xuICAgICAgICBlc1Jlc3AgPSBhd2FpdCBjbGllbnQuY2FsbEFzQ3VycmVudFVzZXIoJ29wZW5kaXN0cm9fc2VjdXJpdHkuZGVsZXRlUmVzb3VyY2UnLCB7XG4gICAgICAgICAgcmVzb3VyY2VOYW1lOiByZXF1ZXN0LnBhcmFtcy5yZXNvdXJjZU5hbWUsXG4gICAgICAgICAgaWQ6IHJlcXVlc3QucGFyYW1zLmlkLFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcbiAgICAgICAgICBib2R5OiB7XG4gICAgICAgICAgICBtZXNzYWdlOiBlc1Jlc3AubWVzc2FnZSxcbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHJldHVybiBlcnJvclJlc3BvbnNlKHJlc3BvbnNlLCBlcnJvcik7XG4gICAgICB9XG4gICAgfVxuICApO1xuXG4gIC8qKlxuICAgKiBVcGRhdGUgb2JqZWN0IHdpdGggb3V0IElkLiBSZXNvdXJjZSBpZGVudGlmaWNhdGlvbiBpcyBleHBlY3RlZCB0byBjb21wdXRlZCBmcm9tIGhlYWRlcnMuIEVnOiBhdXRoIGhlYWRlcnNcbiAgICpcbiAgICogUmVxdWVzdCBzYW1wbGU6XG4gICAqIC9jb25maWd1cmF0aW9uL2FjY291bnRcbiAgICoge1xuICAgKiAgIFwicGFzc3dvcmRcIjogXCJuZXctcGFzc3dvcmRcIixcbiAgICogICBcImN1cnJlbnRfcGFzc3dvcmRcIjogXCJvbGQtcGFzc3dvcmRcIlxuICAgKiB9XG4gICAqL1xuICByb3V0ZXIucG9zdChcbiAgICB7XG4gICAgICBwYXRoOiBgJHtBUElfUFJFRklYfS8ke0NPTkZJR1VSQVRJT05fQVBJX1BSRUZJWH0ve3Jlc291cmNlTmFtZX1gLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgcGFyYW1zOiBzY2hlbWEub2JqZWN0KHtcbiAgICAgICAgICByZXNvdXJjZU5hbWU6IHNjaGVtYS5zdHJpbmcoKSxcbiAgICAgICAgfSksXG4gICAgICAgIGJvZHk6IHNjaGVtYS5hbnkoKSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpOiBQcm9taXNlPElLaWJhbmFSZXNwb25zZTxhbnkgfCBSZXNwb25zZUVycm9yPj4gPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgdmFsaWRhdGVSZXF1ZXN0Qm9keShyZXF1ZXN0LnBhcmFtcy5yZXNvdXJjZU5hbWUsIHJlcXVlc3QuYm9keSk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICByZXR1cm4gcmVzcG9uc2UuYmFkUmVxdWVzdCh7IGJvZHk6IGVycm9yIH0pO1xuICAgICAgfVxuICAgICAgY29uc3QgY2xpZW50ID0gY29udGV4dC5zZWN1cml0eV9wbHVnaW4uZXNDbGllbnQuYXNTY29wZWQocmVxdWVzdCk7XG4gICAgICBsZXQgZXNSZXNwO1xuICAgICAgdHJ5IHtcbiAgICAgICAgZXNSZXNwID0gYXdhaXQgY2xpZW50LmNhbGxBc0N1cnJlbnRVc2VyKCdvcGVuZGlzdHJvX3NlY3VyaXR5LnNhdmVSZXNvdXJjZVdpdGhvdXRJZCcsIHtcbiAgICAgICAgICByZXNvdXJjZU5hbWU6IHJlcXVlc3QucGFyYW1zLnJlc291cmNlTmFtZSxcbiAgICAgICAgICBib2R5OiByZXF1ZXN0LmJvZHksXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgIG1lc3NhZ2U6IGVzUmVzcC5tZXNzYWdlLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgcmV0dXJuIGVycm9yUmVzcG9uc2UocmVzcG9uc2UsIGVycm9yKTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgLyoqXG4gICAqIFVwZGF0ZSBlbnRpdHkgYnkgSWQuXG4gICAqL1xuICByb3V0ZXIucG9zdChcbiAgICB7XG4gICAgICBwYXRoOiBgJHtBUElfUFJFRklYfS8ke0NPTkZJR1VSQVRJT05fQVBJX1BSRUZJWH0ve3Jlc291cmNlTmFtZX0ve2lkfWAsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBwYXJhbXM6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIHJlc291cmNlTmFtZTogc2NoZW1hLnN0cmluZygpLFxuICAgICAgICAgIGlkOiBzY2hlbWEuc3RyaW5nKHtcbiAgICAgICAgICAgIHZhbGlkYXRlOiB2YWxpZGF0ZUVudGl0eUlkLFxuICAgICAgICAgIH0pLFxuICAgICAgICB9KSxcbiAgICAgICAgYm9keTogc2NoZW1hLmFueSgpLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSk6IFByb21pc2U8SUtpYmFuYVJlc3BvbnNlPGFueSB8IFJlc3BvbnNlRXJyb3I+PiA9PiB7XG4gICAgICB0cnkge1xuICAgICAgICB2YWxpZGF0ZVJlcXVlc3RCb2R5KHJlcXVlc3QucGFyYW1zLnJlc291cmNlTmFtZSwgcmVxdWVzdC5ib2R5KTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5iYWRSZXF1ZXN0KHsgYm9keTogZXJyb3IgfSk7XG4gICAgICB9XG4gICAgICBjb25zdCBjbGllbnQgPSBjb250ZXh0LnNlY3VyaXR5X3BsdWdpbi5lc0NsaWVudC5hc1Njb3BlZChyZXF1ZXN0KTtcbiAgICAgIGxldCBlc1Jlc3A7XG4gICAgICB0cnkge1xuICAgICAgICBlc1Jlc3AgPSBhd2FpdCBjbGllbnQuY2FsbEFzQ3VycmVudFVzZXIoJ29wZW5kaXN0cm9fc2VjdXJpdHkuc2F2ZVJlc291cmNlJywge1xuICAgICAgICAgIHJlc291cmNlTmFtZTogcmVxdWVzdC5wYXJhbXMucmVzb3VyY2VOYW1lLFxuICAgICAgICAgIGlkOiByZXF1ZXN0LnBhcmFtcy5pZCxcbiAgICAgICAgICBib2R5OiByZXF1ZXN0LmJvZHksXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgIG1lc3NhZ2U6IGVzUmVzcC5tZXNzYWdlLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgcmV0dXJuIGVycm9yUmVzcG9uc2UocmVzcG9uc2UsIGVycm9yKTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgLyoqXG4gICAqIEdldHMgYXV0aGVudGljYXRpb24gaW5mbyBvZiB0aGUgdXNlci5cbiAgICpcbiAgICogVGhlIHJlc3BvbnNlIGxvb2tzIGxpa2U6XG4gICAqIHtcbiAgICogICBcInVzZXJcIjogXCJVc2VyIFtuYW1lPWFkbWluLCByb2xlcz1bXSwgcmVxdWVzdGVkVGVuYW50PV9fdXNlcl9fXVwiLFxuICAgKiAgIFwidXNlcl9uYW1lXCI6IFwiYWRtaW5cIixcbiAgICogICBcInVzZXJfcmVxdWVzdGVkX3RlbmFudFwiOiBcIl9fdXNlcl9fXCIsXG4gICAqICAgXCJyZW1vdGVfYWRkcmVzc1wiOiBcIjEyNy4wLjAuMTozNTA0NFwiLFxuICAgKiAgIFwiYmFja2VuZF9yb2xlc1wiOiBbXSxcbiAgICogICBcImN1c3RvbV9hdHRyaWJ1dGVfbmFtZXNcIjogW10sXG4gICAqICAgXCJyb2xlc1wiOiBbXCJhbGxfYWNjZXNzXCIsIFwic2VjdXJpdHlfbWFuYWdlclwiXSxcbiAgICogICBcInRlbmFudHNcIjoge1xuICAgKiAgICAgXCJhbm90aGVyX3RlbmFudFwiOiB0cnVlLFxuICAgKiAgICAgXCJhZG1pblwiOiB0cnVlLFxuICAgKiAgICAgXCJnbG9iYWxfdGVuYW50XCI6IHRydWUsXG4gICAqICAgICBcImFhYWFhXCI6IHRydWUsXG4gICAqICAgICBcInRlc3QgdGVuYW50XCI6IHRydWVcbiAgICogICB9LFxuICAgKiAgIFwicHJpbmNpcGFsXCI6IG51bGwsXG4gICAqICAgXCJwZWVyX2NlcnRpZmljYXRlc1wiOiBcIjBcIixcbiAgICogICBcInNzb19sb2dvdXRfdXJsXCI6IG51bGxcbiAgICogfVxuICAgKi9cbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiBgJHtBUElfUFJFRklYfS9hdXRoL2F1dGhpbmZvYCxcbiAgICAgIHZhbGlkYXRlOiBmYWxzZSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSk6IFByb21pc2U8SUtpYmFuYVJlc3BvbnNlPGFueSB8IFJlc3BvbnNlRXJyb3I+PiA9PiB7XG4gICAgICBjb25zdCBjbGllbnQgPSBjb250ZXh0LnNlY3VyaXR5X3BsdWdpbi5lc0NsaWVudC5hc1Njb3BlZChyZXF1ZXN0KTtcbiAgICAgIGxldCBlc1Jlc3A7XG4gICAgICB0cnkge1xuICAgICAgICBlc1Jlc3AgPSBhd2FpdCBjbGllbnQuY2FsbEFzQ3VycmVudFVzZXIoJ29wZW5kaXN0cm9fc2VjdXJpdHkuYXV0aGluZm8nKTtcblxuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICAgIGJvZHk6IGVzUmVzcCxcbiAgICAgICAgfSk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICByZXR1cm4gZXJyb3JSZXNwb25zZShyZXNwb25zZSwgZXJyb3IpO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICAvKipcbiAgICogR2V0cyBhdWRpdCBsb2cgY29uZmlndXJhdGlvbuOAglxuICAgKlxuICAgKiBTYW1wbGUgcGF5bG9hZDpcbiAgICoge1xuICAgKiAgIFwiZW5hYmxlZFwiOnRydWUsXG4gICAqICAgXCJhdWRpdFwiOntcbiAgICogICAgIFwiZW5hYmxlX3Jlc3RcIjpmYWxzZSxcbiAgICogICAgIFwiZGlzYWJsZWRfcmVzdF9jYXRlZ29yaWVzXCI6W1xuICAgKiAgICAgICBcIkZBSUxFRF9MT0dJTlwiLFxuICAgKiAgICAgICBcIkFVVEhFTlRJQ0FURURcIlxuICAgKiAgICAgXSxcbiAgICogICAgIFwiZW5hYmxlX3RyYW5zcG9ydFwiOnRydWUsXG4gICAqICAgICBcImRpc2FibGVkX3RyYW5zcG9ydF9jYXRlZ29yaWVzXCI6W1xuICAgKiAgICAgICBcIkdSQU5URURfUFJJVklMRUdFU1wiXG4gICAqICAgICBdLFxuICAgKiAgICAgXCJyZXNvbHZlX2J1bGtfcmVxdWVzdHNcIjp0cnVlLFxuICAgKiAgICAgXCJsb2dfcmVxdWVzdF9ib2R5XCI6ZmFsc2UsXG4gICAqICAgICBcInJlc29sdmVfaW5kaWNlc1wiOnRydWUsXG4gICAqICAgICBcImV4Y2x1ZGVfc2Vuc2l0aXZlX2hlYWRlcnNcIjp0cnVlLFxuICAgKiAgICAgXCJpZ25vcmVfdXNlcnNcIjpbXG4gICAqICAgICAgIFwiYWRtaW5cIixcbiAgICogICAgIF0sXG4gICAqICAgICBcImlnbm9yZV9yZXF1ZXN0c1wiOltcbiAgICogICAgICAgXCJTZWFyY2hSZXF1ZXN0XCIsXG4gICAqICAgICAgIFwiaW5kaWNlczpkYXRhL3JlYWQvKlwiXG4gICAqICAgICBdXG4gICAqICAgfSxcbiAgICogICBcImNvbXBsaWFuY2VcIjp7XG4gICAqICAgICBcImVuYWJsZWRcIjp0cnVlLFxuICAgKiAgICAgXCJpbnRlcm5hbF9jb25maWdcIjpmYWxzZSxcbiAgICogICAgIFwiZXh0ZXJuYWxfY29uZmlnXCI6ZmFsc2UsXG4gICAqICAgICBcInJlYWRfbWV0YWRhdGFfb25seVwiOmZhbHNlLFxuICAgKiAgICAgXCJyZWFkX3dhdGNoZWRfZmllbGRzXCI6e1xuICAgKiAgICAgICBcImluZGV4TmFtZTFcIjpbXG4gICAqICAgICAgICAgXCJmaWVsZDFcIixcbiAgICogICAgICAgICBcImZpZWxkcy0qXCJcbiAgICogICAgICAgXVxuICAgKiAgICAgfSxcbiAgICogICAgIFwicmVhZF9pZ25vcmVfdXNlcnNcIjpbXG4gICAqICAgICAgIFwia2liYW5hc2VydmVyXCIsXG4gICAqICAgICAgIFwib3BlcmF0b3IvKlwiXG4gICAqICAgICBdLFxuICAgKiAgICAgXCJ3cml0ZV9tZXRhZGF0YV9vbmx5XCI6ZmFsc2UsXG4gICAqICAgICBcIndyaXRlX2xvZ19kaWZmc1wiOmZhbHNlLFxuICAgKiAgICAgXCJ3cml0ZV93YXRjaGVkX2luZGljZXNcIjpbXG4gICAqICAgICAgIFwiaW5kZXhOYW1lMlwiLFxuICAgKiAgICAgICBcImluZGV4UGF0dGVybnMtKlwiXG4gICAqICAgICBdLFxuICAgKiAgICAgXCJ3cml0ZV9pZ25vcmVfdXNlcnNcIjpbXG4gICAqICAgICAgIFwiYWRtaW5cIlxuICAgKiAgICAgXVxuICAgKiAgIH1cbiAgICogfVxuICAgKi9cbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiBgJHtBUElfUFJFRklYfS9jb25maWd1cmF0aW9uL2F1ZGl0YCxcbiAgICAgIHZhbGlkYXRlOiBmYWxzZSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSk6IFByb21pc2U8SUtpYmFuYVJlc3BvbnNlPGFueSB8IFJlc3BvbnNlRXJyb3I+PiA9PiB7XG4gICAgICBjb25zdCBjbGllbnQgPSBjb250ZXh0LnNlY3VyaXR5X3BsdWdpbi5lc0NsaWVudC5hc1Njb3BlZChyZXF1ZXN0KTtcblxuICAgICAgbGV0IGVzUmVzcDtcbiAgICAgIHRyeSB7XG4gICAgICAgIGVzUmVzcCA9IGF3YWl0IGNsaWVudC5jYWxsQXNDdXJyZW50VXNlcignb3BlbmRpc3Ryb19zZWN1cml0eS5nZXRBdWRpdCcpO1xuXG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgICAgYm9keTogZXNSZXNwLFxuICAgICAgICB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5jdXN0b20oe1xuICAgICAgICAgIHN0YXR1c0NvZGU6IGVycm9yLnN0YXR1c0NvZGUsXG4gICAgICAgICAgYm9keTogcGFyc2VFc0Vycm9yUmVzcG9uc2UoZXJyb3IpLFxuICAgICAgICB9KTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgLyoqXG4gICAqIFVwZGF0ZSBhdWRpdCBsb2cgY29uZmlndXJhdGlvbuOAglxuICAgKlxuICAgKiBTYW1wbGUgcGF5bG9hZDpcbiAgICoge1xuICAgKiAgIFwiZW5hYmxlZFwiOnRydWUsXG4gICAqICAgXCJhdWRpdFwiOntcbiAgICogICAgIFwiZW5hYmxlX3Jlc3RcIjpmYWxzZSxcbiAgICogICAgIFwiZGlzYWJsZWRfcmVzdF9jYXRlZ29yaWVzXCI6W1xuICAgKiAgICAgICBcIkZBSUxFRF9MT0dJTlwiLFxuICAgKiAgICAgICBcIkFVVEhFTlRJQ0FURURcIlxuICAgKiAgICAgXSxcbiAgICogICAgIFwiZW5hYmxlX3RyYW5zcG9ydFwiOnRydWUsXG4gICAqICAgICBcImRpc2FibGVkX3RyYW5zcG9ydF9jYXRlZ29yaWVzXCI6W1xuICAgKiAgICAgICBcIkdSQU5URURfUFJJVklMRUdFU1wiXG4gICAqICAgICBdLFxuICAgKiAgICAgXCJyZXNvbHZlX2J1bGtfcmVxdWVzdHNcIjp0cnVlLFxuICAgKiAgICAgXCJsb2dfcmVxdWVzdF9ib2R5XCI6ZmFsc2UsXG4gICAqICAgICBcInJlc29sdmVfaW5kaWNlc1wiOnRydWUsXG4gICAqICAgICBcImV4Y2x1ZGVfc2Vuc2l0aXZlX2hlYWRlcnNcIjp0cnVlLFxuICAgKiAgICAgXCJpZ25vcmVfdXNlcnNcIjpbXG4gICAqICAgICAgIFwiYWRtaW5cIixcbiAgICogICAgIF0sXG4gICAqICAgICBcImlnbm9yZV9yZXF1ZXN0c1wiOltcbiAgICogICAgICAgXCJTZWFyY2hSZXF1ZXN0XCIsXG4gICAqICAgICAgIFwiaW5kaWNlczpkYXRhL3JlYWQvKlwiXG4gICAqICAgICBdXG4gICAqICAgfSxcbiAgICogICBcImNvbXBsaWFuY2VcIjp7XG4gICAqICAgICBcImVuYWJsZWRcIjp0cnVlLFxuICAgKiAgICAgXCJpbnRlcm5hbF9jb25maWdcIjpmYWxzZSxcbiAgICogICAgIFwiZXh0ZXJuYWxfY29uZmlnXCI6ZmFsc2UsXG4gICAqICAgICBcInJlYWRfbWV0YWRhdGFfb25seVwiOmZhbHNlLFxuICAgKiAgICAgXCJyZWFkX3dhdGNoZWRfZmllbGRzXCI6e1xuICAgKiAgICAgICBcImluZGV4TmFtZTFcIjpbXG4gICAqICAgICAgICAgXCJmaWVsZDFcIixcbiAgICogICAgICAgICBcImZpZWxkcy0qXCJcbiAgICogICAgICAgXVxuICAgKiAgICAgfSxcbiAgICogICAgIFwicmVhZF9pZ25vcmVfdXNlcnNcIjpbXG4gICAqICAgICAgIFwia2liYW5hc2VydmVyXCIsXG4gICAqICAgICAgIFwib3BlcmF0b3IvKlwiXG4gICAqICAgICBdLFxuICAgKiAgICAgXCJ3cml0ZV9tZXRhZGF0YV9vbmx5XCI6ZmFsc2UsXG4gICAqICAgICBcIndyaXRlX2xvZ19kaWZmc1wiOmZhbHNlLFxuICAgKiAgICAgXCJ3cml0ZV93YXRjaGVkX2luZGljZXNcIjpbXG4gICAqICAgICAgIFwiaW5kZXhOYW1lMlwiLFxuICAgKiAgICAgICBcImluZGV4UGF0dGVybnMtKlwiXG4gICAqICAgICBdLFxuICAgKiAgICAgXCJ3cml0ZV9pZ25vcmVfdXNlcnNcIjpbXG4gICAqICAgICAgIFwiYWRtaW5cIlxuICAgKiAgICAgXVxuICAgKiAgIH1cbiAgICogfVxuICAgKi9cbiAgcm91dGVyLnBvc3QoXG4gICAge1xuICAgICAgcGF0aDogYCR7QVBJX1BSRUZJWH0vY29uZmlndXJhdGlvbi9hdWRpdC9jb25maWdgLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgYm9keTogc2NoZW1hLmFueSgpLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSkgPT4ge1xuICAgICAgY29uc3QgY2xpZW50ID0gY29udGV4dC5zZWN1cml0eV9wbHVnaW4uZXNDbGllbnQuYXNTY29wZWQocmVxdWVzdCk7XG4gICAgICBsZXQgZXNSZXNwO1xuICAgICAgdHJ5IHtcbiAgICAgICAgZXNSZXNwID0gYXdhaXQgY2xpZW50LmNhbGxBc0N1cnJlbnRVc2VyKCdvcGVuZGlzdHJvX3NlY3VyaXR5LnNhdmVBdWRpdCcsIHtcbiAgICAgICAgICBib2R5OiByZXF1ZXN0LmJvZHksXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICAgIGJvZHk6IHtcbiAgICAgICAgICAgIG1lc3NhZ2U6IGVzUmVzcC5tZXNzYWdlLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgcmV0dXJuIGVycm9yUmVzcG9uc2UocmVzcG9uc2UsIGVycm9yKTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgLyoqXG4gICAqIERlbGV0ZXMgY2FjaGUuXG4gICAqXG4gICAqIFNhbXBsZSByZXNwb25zZToge1wibWVzc2FnZVwiOlwiQ2FjaGUgZmx1c2hlZCBzdWNjZXNzZnVsbHkuXCJ9XG4gICAqL1xuICByb3V0ZXIuZGVsZXRlKFxuICAgIHtcbiAgICAgIHBhdGg6IGAke0FQSV9QUkVGSVh9L2NvbmZpZ3VyYXRpb24vY2FjaGVgLFxuICAgICAgdmFsaWRhdGU6IGZhbHNlLFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICBjb25zdCBjbGllbnQgPSBjb250ZXh0LnNlY3VyaXR5X3BsdWdpbi5lc0NsaWVudC5hc1Njb3BlZChyZXF1ZXN0KTtcbiAgICAgIGxldCBlc1Jlc3BvbnNlO1xuICAgICAgdHJ5IHtcbiAgICAgICAgZXNSZXNwb25zZSA9IGF3YWl0IGNsaWVudC5jYWxsQXNDdXJyZW50VXNlcignb3BlbmRpc3Ryb19zZWN1cml0eS5jbGVhckNhY2hlJyk7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgICAgYm9keToge1xuICAgICAgICAgICAgbWVzc2FnZTogZXNSZXNwb25zZS5tZXNzYWdlLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgcmV0dXJuIGVycm9yUmVzcG9uc2UocmVzcG9uc2UsIGVycm9yKTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgLyoqXG4gICAqIEdldHMgcGVybWlzc2lvbiBpbmZvIG9mIGN1cnJlbnQgdXNlci5cbiAgICpcbiAgICogU2FtcGxlIHJlc3BvbnNlOlxuICAgKiB7XG4gICAqICAgXCJ1c2VyXCI6IFwiVXNlciBbbmFtZT1hZG1pbiwgcm9sZXM9W10sIHJlcXVlc3RlZFRlbmFudD1fX3VzZXJfX11cIixcbiAgICogICBcInVzZXJfbmFtZVwiOiBcImFkbWluXCIsXG4gICAqICAgXCJoYXNfYXBpX2FjY2Vzc1wiOiB0cnVlLFxuICAgKiAgIFwiZGlzYWJsZWRfZW5kcG9pbnRzXCI6IHt9XG4gICAqIH1cbiAgICovXG4gIHJvdXRlci5nZXQoXG4gICAge1xuICAgICAgcGF0aDogYCR7QVBJX1BSRUZJWH0vcmVzdGFwaWluZm9gLFxuICAgICAgdmFsaWRhdGU6IGZhbHNlLFxuICAgIH0sXG4gICAgYXN5bmMgKGNvbnRleHQsIHJlcXVlc3QsIHJlc3BvbnNlKSA9PiB7XG4gICAgICBjb25zdCBjbGllbnQgPSBjb250ZXh0LnNlY3VyaXR5X3BsdWdpbi5lc0NsaWVudC5hc1Njb3BlZChyZXF1ZXN0KTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGVzUmVzcG9uc2UgPSBhd2FpdCBjbGllbnQuY2FsbEFzQ3VycmVudFVzZXIoJ29wZW5kaXN0cm9fc2VjdXJpdHkucmVzdGFwaWluZm8nKTtcbiAgICAgICAgcmV0dXJuIHJlc3BvbnNlLm9rKHtcbiAgICAgICAgICBib2R5OiBlc1Jlc3BvbnNlLFxuICAgICAgICB9KTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5iYWRSZXF1ZXN0KHtcbiAgICAgICAgICBib2R5OiBlcnJvcixcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgfVxuICApO1xuXG4gIC8qKlxuICAgKiBWYWxpZGF0ZXMgRExTIChkb2N1bWVudCBsZXZlbCBzZWN1cml0eSkgcXVlcnkuXG4gICAqXG4gICAqIFJlcXVlc3QgcGF5bG9hZCBpcyBhbiBFUyBxdWVyeS5cbiAgICovXG4gIHJvdXRlci5wb3N0KFxuICAgIHtcbiAgICAgIHBhdGg6IGAke0FQSV9QUkVGSVh9LyR7Q09ORklHVVJBVElPTl9BUElfUFJFRklYfS92YWxpZGF0ZWRscy97aW5kZXhOYW1lfWAsXG4gICAgICB2YWxpZGF0ZToge1xuICAgICAgICBwYXJhbXM6IHNjaGVtYS5vYmplY3Qoe1xuICAgICAgICAgIC8vIGluIGxlZ2FjeSBwbHVnaW4gaW1wbG1lbnRhdGlvbiwgaW5kZXhOYW1lIGlzIG5vdCB1c2VkIHdoZW4gY2FsbGluZyBFUyBBUEkuXG4gICAgICAgICAgaW5kZXhOYW1lOiBzY2hlbWEubWF5YmUoc2NoZW1hLnN0cmluZygpKSxcbiAgICAgICAgfSksXG4gICAgICAgIGJvZHk6IHNjaGVtYS5hbnkoKSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcbiAgICAgIGNvbnN0IGNsaWVudCA9IGNvbnRleHQuc2VjdXJpdHlfcGx1Z2luLmVzQ2xpZW50LmFzU2NvcGVkKHJlcXVlc3QpO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgZXNSZXNwb25zZSA9IGF3YWl0IGNsaWVudC5jYWxsQXNDdXJyZW50VXNlcignb3BlbmRpc3Ryb19zZWN1cml0eS52YWxpZGF0ZURscycsIHtcbiAgICAgICAgICBib2R5OiByZXF1ZXN0LmJvZHksXG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gcmVzcG9uc2Uub2soe1xuICAgICAgICAgIGJvZHk6IGVzUmVzcG9uc2UsXG4gICAgICAgIH0pO1xuICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgcmV0dXJuIGVycm9yUmVzcG9uc2UocmVzcG9uc2UsIGVycm9yKTtcbiAgICAgIH1cbiAgICB9XG4gICk7XG5cbiAgLyoqXG4gICAqIEdldHMgaW5kZXggbWFwcGluZy5cbiAgICpcbiAgICogQ2FsbGluZyBFUyBfbWFwcGluZyBBUEkgdW5kZXIgdGhlIGhvb2QuIHNlZVxuICAgKiBodHRwczovL3d3dy5lbGFzdGljLmNvL2d1aWRlL2VuL2VsYXN0aWNzZWFyY2gvcmVmZXJlbmNlL2N1cnJlbnQvaW5kaWNlcy1nZXQtbWFwcGluZy5odG1sXG4gICAqL1xuICByb3V0ZXIucG9zdChcbiAgICB7XG4gICAgICBwYXRoOiBgJHtBUElfUFJFRklYfS8ke0NPTkZJR1VSQVRJT05fQVBJX1BSRUZJWH0vaW5kZXhfbWFwcGluZ3NgLFxuICAgICAgdmFsaWRhdGU6IHtcbiAgICAgICAgYm9keTogc2NoZW1hLm9iamVjdCh7XG4gICAgICAgICAgaW5kZXg6IHNjaGVtYS5hcnJheU9mKHNjaGVtYS5zdHJpbmcoKSksXG4gICAgICAgIH0pLFxuICAgICAgfSxcbiAgICB9LFxuICAgIGFzeW5jIChjb250ZXh0LCByZXF1ZXN0LCByZXNwb25zZSkgPT4ge1xuICAgICAgY29uc3QgY2xpZW50ID0gY29udGV4dC5zZWN1cml0eV9wbHVnaW4uZXNDbGllbnQuYXNTY29wZWQocmVxdWVzdCk7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCBlc1Jlc3BvbnNlID0gYXdhaXQgY2xpZW50LmNhbGxBc0N1cnJlbnRVc2VyKCdvcGVuZGlzdHJvX3NlY3VyaXR5LmdldEluZGV4TWFwcGluZ3MnLCB7XG4gICAgICAgICAgaW5kZXg6IHJlcXVlc3QuYm9keS5pbmRleC5qb2luKCcsJyksXG4gICAgICAgICAgaWdub3JlX3VuYXZhaWxhYmxlOiB0cnVlLFxuICAgICAgICAgIGFsbG93X25vX2luZGljZXM6IHRydWUsXG4gICAgICAgIH0pO1xuXG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgICAgYm9keTogZXNSZXNwb25zZSxcbiAgICAgICAgfSk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICByZXR1cm4gZXJyb3JSZXNwb25zZShyZXNwb25zZSwgZXJyb3IpO1xuICAgICAgfVxuICAgIH1cbiAgKTtcblxuICAvKipcbiAgICogR2V0cyBhbGwgaW5kaWNlcywgYW5kIGZpZWxkIG1hcHBpbmdzLlxuICAgKlxuICAgKiBDYWxscyBFUyBBUEkgJy9fYWxsL19tYXBwaW5nL2ZpZWxkLyonIHVuZGVyIHRoZSBob29kLiBzZWVcbiAgICogaHR0cHM6Ly93d3cuZWxhc3RpYy5jby9ndWlkZS9lbi9lbGFzdGljc2VhcmNoL3JlZmVyZW5jZS9jdXJyZW50L2luZGljZXMtZ2V0LW1hcHBpbmcuaHRtbFxuICAgKi9cbiAgcm91dGVyLmdldChcbiAgICB7XG4gICAgICBwYXRoOiBgJHtBUElfUFJFRklYfS8ke0NPTkZJR1VSQVRJT05fQVBJX1BSRUZJWH0vaW5kaWNlc2AsXG4gICAgICB2YWxpZGF0ZTogZmFsc2UsXG4gICAgfSxcbiAgICBhc3luYyAoY29udGV4dCwgcmVxdWVzdCwgcmVzcG9uc2UpID0+IHtcbiAgICAgIGNvbnN0IGNsaWVudCA9IGNvbnRleHQuc2VjdXJpdHlfcGx1Z2luLmVzQ2xpZW50LmFzU2NvcGVkKHJlcXVlc3QpO1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgZXNSZXNwb25zZSA9IGF3YWl0IGNsaWVudC5jYWxsQXNDdXJyZW50VXNlcignb3BlbmRpc3Ryb19zZWN1cml0eS5pbmRpY2VzJyk7XG4gICAgICAgIHJldHVybiByZXNwb25zZS5vayh7XG4gICAgICAgICAgYm9keTogZXNSZXNwb25zZSxcbiAgICAgICAgfSk7XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICByZXR1cm4gZXJyb3JSZXNwb25zZShyZXNwb25zZSwgZXJyb3IpO1xuICAgICAgfVxuICAgIH1cbiAgKTtcbn1cblxuZnVuY3Rpb24gcGFyc2VFc0Vycm9yUmVzcG9uc2UoZXJyb3I6IGFueSkge1xuICBpZiAoZXJyb3IucmVzcG9uc2UpIHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgZXNFcnJvclJlc3BvbnNlID0gSlNPTi5wYXJzZShlcnJvci5yZXNwb25zZSk7XG4gICAgICByZXR1cm4gZXNFcnJvclJlc3BvbnNlLnJlYXNvbiB8fCBlcnJvci5yZXNwb25zZTtcbiAgICB9IGNhdGNoIChwYXJzaW5nRXJyb3IpIHtcbiAgICAgIHJldHVybiBlcnJvci5yZXNwb25zZTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGVycm9yLm1lc3NhZ2U7XG59XG5cbmZ1bmN0aW9uIGVycm9yUmVzcG9uc2UocmVzcG9uc2U6IEtpYmFuYVJlc3BvbnNlRmFjdG9yeSwgZXJyb3I6IGFueSkge1xuICByZXR1cm4gcmVzcG9uc2UuY3VzdG9tKHtcbiAgICBzdGF0dXNDb2RlOiBlcnJvci5zdGF0dXNDb2RlLFxuICAgIGJvZHk6IHBhcnNlRXNFcnJvclJlc3BvbnNlKGVycm9yKSxcbiAgfSk7XG59XG4iXX0=